#include "config.h"

T_PageOpr IntervPageOpr;
static PT_VedioMem ptIntervPageVedioMem = NULL;
static char* cpVedioMemAddr = NULL;
static int iTime = 3;
static int iInterTime = 3;

T_PageIcon tIntervPageIcon[] = {
    {400 - 128/2, 180-72/2, 128, 72, "./icons/time.bmp",NULL},   
    {400 - 52/2, 180-72/2-28-20, 52, 28, "./icons/inc.bmp",NULL},
    {400 - 52/2, 180-72/2+72+20, 52, 28, "./icons/dec.bmp",NULL},
    {200, 180-72/2+72+20+40, 80, 80, "./icons/ok.bmp",NULL},
    {600-80, 180-72/2+72+20+40, 80, 80, "./icons/cancel.bmp",NULL},
};


static int DrawIntervPage(PT_VedioMem ptIntervPage)
{
    int i;
    int iError;
    for(i = 0; i < sizeof(tIntervPageIcon)/sizeof(tIntervPageIcon[0]); i++)
    {
        iError |= ShowPicture(ptIntervPage,tIntervPageIcon[i].iXpos,tIntervPageIcon[i].iYpos,tIntervPageIcon[i].cIconName,"bmp");
    }
    return iError;    
}

void ShowStringInScreen(void)
{
    char cTime[5];
    /* ��ʾ��ʼֵ */
    sprintf(cTime,"%d",iTime);
    CleanScreenArea(cpVedioMemAddr,400-128/2+30,400-128/2+128-30,180-72/2+20,180-72/2+72-15,SKY_BLUE);
    if(iTime >= 10)
        ShowString(cpVedioMemAddr, cTime, 400-128/2+30+30-4,180-72/2+20+10,COLOR_WRITE);
    else
        ShowString(cpVedioMemAddr, cTime, 400-128/2+30+30,180-72/2+20+10,COLOR_WRITE);
}

static int ShowIntervPage(void)
{
	/* ���IntervPage �Դ� */
	if((ptIntervPageVedioMem = GetVedioMem(INTERVAL_PAGE_ID)) == NULL)
	{
        DEBUG_Print("Interv page get memory failed\n");
        return -1;
	}
	ptIntervPageVedioMem->iID = INTERVAL_PAGE_ID;
	
	/* ����Դ�Ϊ����������� */
	if(ptIntervPageVedioMem->eVedioMemFill == VMF_NFILL)
	{
	    DEBUG_Print("Interv page fill data\n");
        if(DrawIntervPage(ptIntervPageVedioMem) < 0)
        return -1;
        ptIntervPageVedioMem->eVedioMemFill = VMF_FILLED;
	}
	return 0;
}

static int LoadIntervPageToVedioMem(void)
{
    cpVedioMemAddr = GetDispVedioMemAddr();
    if(cpVedioMemAddr <= 0)
    {
        DEBUG_Print("GetDispVedioMemAddr Error\n");
        return -1;
    }
    memcpy(cpVedioMemAddr,ptIntervPageVedioMem->ucPixelDatas,\
    ptIntervPageVedioMem->iVedioHeight * ptIntervPageVedioMem->iVedioWidth * 4);
    ShowStringInScreen();
    return 0;
}



static int IntervPageButtonAction(int iID)
{
    char cTime[5];
    int iError;
    switch(iID)
    {
        case 0:
        {
            /* button0 */
            
        }
        break;
        case 1:
        {
            /* button1 */
            ++iTime;
            if(iTime > 99)
            iTime = 99;
            ShowStringInScreen();            
        }
        break;
        case 2:
        {
            /* button2 */
            --iTime;
            if(iTime <= 1)
            iTime = 1;
            ShowStringInScreen();
        }
        break;
        case 3:
        {
            /* button3 */
            iInterTime = iTime;
            iError = PageRun("mainpage")->PageRun(NULL);
        }
        break;
        case 4:
        {
            /* button4 */
            iTime = iInterTime;
            iError = PageRun("mainpage")->PageRun(NULL);
        }
        break;
        default: break;
    }
    return iError;
}


int GetInervalTime(void)
{
    return iInterTime;
}

static int IntervPageGetEvent(void)
{
    int iError;
    int i;
	PT_InputEvent ptInputEvent;
    ptInputEvent = (PT_InputEvent)malloc(sizeof(T_InputEvent));
    if(ptInputEvent < 0)
    {
        DEBUG_Print("ptInputEvent malloc failed\n");
        return -1;
    }
    while(1)
    {
	    if(GetInputState(ptInputEvent) == 0)
		{
			if(ptInputEvent->eKeyState == KEY_RELEASE)
			{
			    for(i = 0; i < sizeof(tIntervPageIcon)/sizeof(tIntervPageIcon[0]); i++)
			    {
                    if((ptInputEvent->iXpos >= tIntervPageIcon[i].iXpos) && \
                       (ptInputEvent->iXpos <= tIntervPageIcon[i].iXpos + tIntervPageIcon[i].iWidth) &&\
                       (ptInputEvent->iYpos >= tIntervPageIcon[i].iYpos) &&\
                       (ptInputEvent->iYpos <= tIntervPageIcon[i].iYpos + tIntervPageIcon[i].iHeight))
                    {
                        /* �����ͷ� */
                        DEBUG_Print("%s key %d release\n",__FUNCTION__, i);
                        iError = IntervPageButtonAction(i);
                        if(iError < 0)
                        {
                            DEBUG_Print("Error IntervPageButtonAction\n");
                            return -1;
                        }
                    }
			    }
			}
		}
    }
    free(ptInputEvent);
    return 0;
}

static int IntervPageRun(PT_PageIcon ptPageIcon)
{
    int iError;
    iError = ShowIntervPage();
    iError |= LoadIntervPageToVedioMem();
    iError |= IntervPageGetEvent();
    return iError;
}


T_PageOpr IntervPageOpr = {
    .name = "intervalpage",
    .PageRun = IntervPageRun,
};

int IntervPageRegister(void)
{
    return (RegisterPageOpr(&IntervPageOpr));
}




