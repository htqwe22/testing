#include "config.h"
#include <pthread.h>
#include <signal.h>


T_PageOpr AutoPageOpr;
static PT_VedioMem ptAutoPageVedioMem = NULL;
static int iTouchPressed = 0;

static int GetPictureMem(void)
{
    int iError;
	/* ���AutoPage �Դ� */
	if((ptAutoPageVedioMem = GetVedioMem(AUTO_PAGE_ID)) == NULL)
	{
        DEBUG_Print("Auto page get memory failed\n");
        return -1;
	}
	ptAutoPageVedioMem->iID = AUTO_PAGE_ID;
	
	return 0;
}

static int LoadAutoPageToVedioMem(void)
{
    char* cpVedioMemAddr = NULL;
    cpVedioMemAddr = GetDispVedioMemAddr();
    if(cpVedioMemAddr <= 0)
    {
        DEBUG_Print("GetDispVedioMemAddr Error\n");
        return -1;
    }
    memcpy(cpVedioMemAddr,ptAutoPageVedioMem->ucPixelDatas,\
    ptAutoPageVedioMem->iVedioHeight * ptAutoPageVedioMem->iVedioWidth * 4);
    return 0;
}

static int AutoPageGetEvent(void)
{
    int iError;
    int i;
	PT_InputEvent ptInputEvent;
    ptInputEvent = (PT_InputEvent)malloc(sizeof(T_InputEvent));
    if(ptInputEvent < 0)
    {
        DEBUG_Print("ptInputEvent malloc failed\n");
        return -1;
    }
    while(1)
    {
	    if(GetInputState(ptInputEvent) == 0)
		{
			if(ptInputEvent->eKeyState == KEY_RELEASE)
			{
			    /* ptAutoPageVedioMem���ٿ��������δ��� */
			    if((ptInputEvent->iXpos > ptAutoPageVedioMem->iVedioWidth / 3) &&\
			       (ptInputEvent->iXpos < ptAutoPageVedioMem->iVedioWidth * 2 / 3))
			    {
			        //iTouchPressed = 1;
			        break;
			    }
			}
		}
    }
    free(ptInputEvent);
    return 0;
}

void *AutoPageChiledThread(void *argc)
{
    int iError;
    FILE* fp;
    char cBuff[MAX_FILE_LENTH + 1];
    char cPathBuff[MAX_FILE_LENTH + 1];
    int iIntervalTime =  0;

    iIntervalTime = GetInervalTime();
    pthread_setcancelstate( PTHREAD_CANCEL_ENABLE, NULL);     //�����˳��߳�
    pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS, NULL); //��������ȡ��
    while(1)
    {
        /* �Զ������ļ��� */
        fp = popen("ls *jpg", "r");   
        if(fp == NULL)
        {
            DEBUG_Print("Error popen\n");
            pthread_exit(1);
        }
        
        /* ���Ҫ��ʾͼƬ���ļ��� */
        while(fgets(cBuff, MAX_FILE_LENTH, fp) != NULL)
        {
            /* ȥ������Ļ��з� */
            memcpy(cPathBuff, cBuff, strlen(cBuff) - 1);
            cPathBuff[strlen(cBuff) - 1] = '\0';
            DEBUG_Print("Picture: %s\n",cPathBuff);
            /* �������*/

            /* ���һ��ͼƬ���� */
		    iError = ShowPicture(ptAutoPageVedioMem,0,0,cPathBuff,"jpeg");
		    if(iError < 0)
		    {
		        DEBUG_Print("Error ShowPicture, %s\n",__FUNCTION__);
		        return 0;
		    }
			ptAutoPageVedioMem->eVedioMemFill = VMF_FILLED;
            
			/* ��ʾ����ͼƬ */
            iError |= LoadAutoPageToVedioMem();
            if(iError < 0)
            {
                DEBUG_Print("Error LoadAutoPageToVedioMem, %s\n",__FUNCTION__);
            }

            /* ˯��ָ��ʱ����ʾ��һ�� */
            sleep(iIntervalTime);
            
        }
    }
    pthread_exit(0);
}

void sighand(int signo)
{
    pthread_t tid = pthread_self();
    DEBUG_Print("pthread %lu in signal hander\n",tid);
}

static int AutoPageMainThread(void)
{
    int iError;
    int ret;
    pthread_t ptID;

    pthread_create(&ptID, NULL, AutoPageChiledThread, NULL);

	/* �е���¼����˳��Զ��ֲ����߳� */
    ret = AutoPageGetEvent();
    if(ret == 0)
    {
        DEBUG_Print("chiled thread quit\n");
        /* �˳����߳� */
        pthread_cancel(ptID);
    }
    /* �ȴ����߳��˳� */
    pthread_join(ptID, NULL);
    return 0;
}

static int AutoPageRun(PT_PageIcon ptPageIcon)
{
    int iError;
    /* ���һ���ڴ� */
    iError = GetPictureMem();      
    iError |= AutoPageMainThread();
    if(iError == 0)
    {
	    iError = PageRun("mainpage")->PageRun(NULL);
    }
    /* �ͷ��Դ� */
    ptAutoPageVedioMem->iID = -1;
    PutVedioMem(ptAutoPageVedioMem);
    return iError;
}


T_PageOpr AutoPageOpr = {
    .name = "autopage",
    .PageRun = AutoPageRun,
};

int AutoPageRegister(void)
{
    return (RegisterPageOpr(&AutoPageOpr));
}



