#include "config.h"

PT_PageOpr ptPageOprHead = NULL;


int RegisterPageOpr(PT_PageOpr ptPageOpr)
{
    PT_PageOpr ptTmp;
    /* �������Ϊ�� */
    if(!ptPageOprHead)
    {
        ptPageOprHead = ptPageOpr;
        ptPageOpr->next = NULL;
    }
    else
    {
        ptTmp = ptPageOprHead;
        while(ptTmp->next)
        {
            ptTmp = ptTmp->next;
        }
        ptTmp->next = ptPageOpr;
        ptPageOpr->next = NULL;
    }
    return 0;
}


PT_PageOpr PageRun(char* cpPageName)
{
    PT_PageOpr ptTmp = ptPageOprHead;
    while(ptTmp)
    {
        if(strcmp(ptTmp->name, cpPageName) == 0)
        {
            DEBUG_Print("prepare run %s\n",ptTmp->name);
            return ptTmp;
        }
        ptTmp = ptTmp->next;
    }
    return (PT_PageOpr)-1;
}

int PageInit(void)
{
    int iError;
    iError = MainPageRegister();
    iError |= IntervPageRegister();
    iError |= AutoPageRegister();
    iError |= ExplorePageRegister();
    iError |= BrowsePageRegister();
    return iError;
}


