#include "config.h"

T_PageOpr ExplorePageOpr;
static PT_VedioMem ptExplorePageVedioMem = NULL;
static FILE* fp;
static int g_iALLFileDispComplt = 1;          /* ��ǰĿ¼�������ļ�����ʾ�� */
static PT_PageIcon g_CurDirFileHead = NULL;      /* ��ǰĿ¼���ļ�����ͷ */
static PT_PageIcon ptPageNum[MAX_FILE_LENTH] = {NULL};    /* ��¼��ǰĿ¼��ÿһҳ�����һ���ļ� */
static int g_iPageNum = 0;
static char cCurOprDir[MAX_FILE_LENTH] = {0};
static int iCurPage = 0;



static int ExplorePageRun(PT_PageIcon ptPageIcon);

T_PageIcon tExplorePageIcon[] = {
    {0, 0, 120, 120, "./icons/up.bmp",NULL},
    {0, 120, 120, 120, "./icons/select.bmp",NULL},
    {0, 240, 120, 120, "./icons/pre_page.bmp",NULL},
    {0, 360, 120, 120, "./icons/next_page.bmp",NULL},
};

static int AddFileToList(PT_PageIcon ptPageIcon)
{
    PT_PageIcon ptTmp;
    /* �������Ϊ�� */
    if(!g_CurDirFileHead)
    {
        g_CurDirFileHead = ptPageIcon;
        ptPageIcon->next = NULL;
    }
    else
    {
        ptTmp = g_CurDirFileHead;
        while(ptTmp->next)
        {
            ptTmp = ptTmp->next;
        }
        ptTmp->next = ptPageIcon;
        ptPageIcon->next = NULL;
    }
    return 0;
}

static void FreeFileList(void)
{
    PT_PageIcon ptTmp1 = g_CurDirFileHead;
    PT_PageIcon ptTmp2 = NULL;
    while(ptTmp1 != NULL) 
    {
        ptTmp2 = ptTmp1->next;
        ptTmp1->next = NULL;
        free(ptTmp1);
        ptTmp1 = ptTmp2;
    }
    g_CurDirFileHead = NULL;
}

void SetMemNull(void)
{
    int i = 0;
    for(i = 0; i < MAX_FILE_LENTH;i++)
    {
        if(ptPageNum[i] != NULL)
            ptPageNum[i] = NULL;
    }
    
}

static void ShowList(void)
{
    PT_PageIcon ptTmp = g_CurDirFileHead;
    while(ptTmp)
    {
        DEBUG_Print("%s\n",ptTmp->cIconName);
        ptTmp = ptTmp->next;
    }
}

/* ���Ŀ¼�µ������ļ� */
int ExploreDirectory(char* cDir)
{
    char cCommand[MAX_FILE_LENTH + 1] = "sh /home/digital/isdir.sh ";
    strncat(cCommand,cDir,strlen(cDir));
    DEBUG_Print("%s\n",cCommand);

    if(chdir(cDir) == -1)
    {
        DEBUG_Print("can't change work dirtory to %s",cDir);
        return -1;
    }
    
	fp = popen(cCommand, "r");   
	if(fp == NULL)
	{
	    DEBUG_Print("Error popen\n");
	    return -1;
	}
	return 0;
}


/* ���û��·����Ϣ���ļ��� */
void GetFileNameWithoutPath(char* cpPath, char* cpName)
{
    int iLenth = strlen(cpPath);
    int iPos = iLenth;
    int iCopySize = 0;
    while(iPos--)
    {
        if(cpPath[iPos] == '/')
            break;
    }
    iCopySize = iLenth - iPos - 1;
    if(iCopySize > (FILE_NAME_SIZE))
        iCopySize = FILE_NAME_SIZE;
    strncpy(cpName, cpPath + iPos + 1, iCopySize);
    cpName[iCopySize] = '\0';
}

static int ShowOneFileOrDir(PT_PageIcon ptIcon, int iXpos, int iYpos)
{
    int iError;
    char cName[FILE_NAME_SIZE + 1];

    GetFileNameWithoutPath(ptIcon->cIconName, cName);
	/* �Ƿ�ΪĿ¼ */
	if(ptIcon->eFileType == TYPE_DIR)
	{
		iError = ShowPicture(ptExplorePageVedioMem,iXpos,iYpos,"/home/digital/icons/fold_opened.bmp","bmp");
		if(iError < 0)
		{
			DEBUG_Print("disp ./icons/fold_opened.bmp filed\n");
			return -1;
		}
		/* ��ʾ�ļ��� */
		ShowString(ptExplorePageVedioMem->ucPixelDatas, cName, iXpos + 40 - strlen(cName)*8/2,iYpos+85,COLOR_WRITE);
	}
	else
	{
		iError = ShowPicture(ptExplorePageVedioMem,iXpos,iYpos,"/home/digital/icons/file.bmp","bmp");
		if(iError < 0)
		{
			DEBUG_Print("disp ./icons/file.bmp filed\n");
			return -1;
		}
		/* ��ʾ�ļ��� */
		ShowString(ptExplorePageVedioMem->ucPixelDatas, cName, iXpos + 40 - strlen(cName)*8/2,iYpos+85,COLOR_WRITE);
	}

}

E_FILE_TYPE FileTypeCheck(char* cpFileName)
{
    int iLenth = strlen(cpFileName);
    /* x.xxx --> a.jpg = 5 */
    if(iLenth < 5)
    {
        return TYPE_OTHER;
    }
    if(strncmp(cpFileName + (iLenth - 4), ".jpg", 4) == 0)
    {
        return TYPE_JPG;
    }
    if(strncmp(cpFileName + (iLenth - 4), ".bmp", 4) == 0)
    {
        return TYPE_BMP;
    }
    return TYPE_OTHER;
}


int DispOnePage(void)
{
    int iError;
    char cBuff[MAX_FILE_LENTH + 1] = {0};
    char cPathBuff[MAX_FILE_LENTH + 1] = {0};
    int iXpos = 180, iYpos = 32;
    PT_PageIcon ptIcon;
    int iFirst = 1;
	struct stat sFileStat;
	

	/* ���Ҫ��ʾͼƬ���ļ��� */
	while(fgets(cBuff, MAX_FILE_LENTH, fp) != NULL)
    {
		/* ���¸�ֵ��ǰĿ¼����ֹ�����ظ����� */
		//memcpy(cPathBuff, cCurOprDir, strlen(cCurOprDir));
		//cPathBuff[strlen(cCurOprDir)] = '\0';
        //DEBUG_Print("cCurOprDir: %s cPathBuff: %s\n",cCurOprDir,cPathBuff);
        /* ��·����ȥ������Ļ��з� */
		//strncat(cPathBuff,cBuff,strlen(cBuff) - 1);
		memcpy(cPathBuff, cBuff, strlen(cBuff) - 1);
		cPathBuff[strlen(cBuff) - 1] = '\0';
		DEBUG_Print("file name: %s\n",cPathBuff);

        
        if(iXpos > (ptExplorePageVedioMem->iVedioWidth - 80))
        {
            iXpos = 180;
            iYpos += (80 + 32);
        }
        if(iYpos > (ptExplorePageVedioMem->iVedioHeight- 80))
        {
            /* ��ʾ������ */
            g_iALLFileDispComplt = 1; 
            //ShowList();
            return 0;
        }
		 
        /* ���ӽ���ǰĿ¼�µ��ļ����� */
        ptIcon = (PT_PageIcon)malloc(sizeof(T_PageIcon));
        if(ptIcon == NULL)
        {
            DEBUG_Print("Error malloc ptIcon\n");
            return -1;
        }
        stat(cPathBuff, &sFileStat);
        if(S_ISDIR(sFileStat.st_mode))
        {
            /* ��һ��Ŀ¼ */
            ptIcon->eFileType = TYPE_DIR;
        }
        else
        {   
            /* ��һ���ļ� */
            ptIcon->eFileType = FileTypeCheck(cPathBuff);
        }
        strncpy(ptIcon->cIconName, cPathBuff, strlen(cPathBuff));
        ptIcon->cIconName[strlen(cPathBuff)] = '\0';
        ptIcon->iXpos = iXpos;
        ptIcon->iYpos = iYpos;
        ptIcon->iWidth = 80;
        ptIcon->iHeight = 80;
        
        ShowOneFileOrDir(ptIcon,iXpos,iYpos);
        AddFileToList(ptIcon);
        /* ��¼��ǰҳ����Ԫ�� */
        if(iFirst)
        {
            ptPageNum[g_iPageNum++] = ptIcon;
            iFirst = 0;
        }
		iXpos += 120;
	}
	g_iALLFileDispComplt = 0;  /* ��ǰĿ¼�������ļ���ʾ���� */
	pclose(fp);
	
	return 0;
}



/* �軭Explorepage */
static int DrawExplorePage(PT_VedioMem ptExplorePage)
{
    int i;
    int iError;
    for(i = 0; i < sizeof(tExplorePageIcon)/sizeof(tExplorePageIcon[0]); i++)
    {
        iError |= ShowPicture(ptExplorePage,tExplorePageIcon[i].iXpos,tExplorePageIcon[i].iYpos,tExplorePageIcon[i].cIconName,"bmp");
    }
    memcpy(cCurOprDir,(const void*)DEFAULT_DIR,strlen(DEFAULT_DIR));
    iError |= ExploreDirectory(DEFAULT_DIR);
    iError |= DispOnePage();
    return iError;
}

static int ShowExplorePage(void)
{
	/* ���ExplorePage �Դ� */
	if((ptExplorePageVedioMem = GetVedioMem(EXPLORE_PAGE_ID)) == NULL)
	{
        DEBUG_Print("Explore page get memory failed\n");
        return -1;
	}
	ptExplorePageVedioMem->iID = EXPLORE_PAGE_ID;
	/* ����Դ�Ϊ����������� */
	if(ptExplorePageVedioMem->eVedioMemFill == VMF_NFILL)
	{
	    DEBUG_Print("Explore page fill data\n");
        if(DrawExplorePage(ptExplorePageVedioMem) < 0)
        return -1;
        ptExplorePageVedioMem->eVedioMemFill = VMF_FILLED;
	}
	return 0;
}

/* �����Դ浽LCD�Դ� */
static int LoadExplorePageToVedioMem(void)
{
    char* cpVedioMemAddr = NULL;
    cpVedioMemAddr = GetDispVedioMemAddr();
    if(cpVedioMemAddr <= 0)
    {
        DEBUG_Print("GetDispVedioMemAddr Error\n");
        return -1;
    }
    memcpy(cpVedioMemAddr,ptExplorePageVedioMem->ucPixelDatas,\
    ptExplorePageVedioMem->iVedioHeight * ptExplorePageVedioMem->iVedioWidth * 4);
    return 0;
}

static int PreAndNextPageHandler(int iPreOrNext)
{
    int iError;
    int iPageNum;
    PT_PageIcon ptPageIconPos = NULL;
    int iXpos = 180, iYpos = 32;


    /* �����������ʾͼ������� */
    /* ��һҳ */
    if(iPreOrNext == GO_PREPAGE)
    {
        iCurPage -= 1;           
        if(iCurPage < 0)    
        {
            iCurPage = 0;
            return 0;
        }
    }
    /* ��һҳ */
    else if(iPreOrNext == GO_NEXTPAGE)
    {
        iCurPage += 1;
    }
    ptPageIconPos = ptPageNum[iCurPage];
    /*
          ptPageIconPos����NULL���������
          1����ǰĿ¼�µ��ļ���û����ȫ��������
          2����ǰĿ¼�µ��ļ�ȫ��������������ȫ����ʾ��û����һҳ��
      */
    if(ptPageIconPos == NULL)
    {
        if(g_iALLFileDispComplt == 0)
        {
            iCurPage -= 1;
            if(iCurPage < 0)
                iCurPage = 0;
            return 0;
        }
        return 1;
    }

    DEBUG_Print("iCurPage: %d\n",iCurPage);
    DEBUG_Print("ptPageIconPos: %s\n",ptPageIconPos->cIconName);
    CleanScreenArea(ptExplorePageVedioMem->ucPixelDatas,120,ptExplorePageVedioMem->iVedioWidth - 1,\
                    0,ptExplorePageVedioMem->iVedioHeight - 1, BLCAK_COLOR);
    while(ptPageIconPos)
    {
	    if(iXpos > (ptExplorePageVedioMem->iVedioWidth - 80))
	    {
	        iXpos = 180;
	        iYpos += (80 + 32);
	    }
	    if(iYpos > (ptExplorePageVedioMem->iVedioHeight- 80))
	    {
	        /* ��ʾ������ */
	        break;
	    }
	    iError = ShowOneFileOrDir(ptPageIconPos,iXpos,iYpos);
	    if(iError < 0)
	    {
            return -1;
	    }
	    ptPageIconPos = ptPageIconPos->next;
	    iXpos += 120;
    }
    /* ���ص��Դ� */
    LoadExplorePageToVedioMem();
    
    return 0;
}


static int GetParentDirtory(char* cPathBuff)
{
    FILE* fp;
    int iLenth = 0;
    char cBuff[MAX_FILE_LENTH + 1] = {0};

    if(chdir("..") == -1)
    {
        DEBUG_Print("can't change work dirtory\n");
        return -1;
    }

    
    /* ��õ�ǰ·�� */
    fp = popen("pwd", "r");   
	if(fp == NULL)
	{
	    DEBUG_Print("Error popen\n");
	    return -1;
	}
	fgets(cBuff,MAX_FILE_LENTH,fp);
	pclose(fp);

    iLenth = strlen(cBuff);
	//DEBUG_Print("cBuff path: %s\n",cBuff);
	//DEBUG_Print("strlen(cBuff): %d\n",iLenth);
	/* ȥ������Ļ��з� */
	memcpy(cPathBuff, cBuff, strlen(cBuff) - 1);
	if(cPathBuff[iLenth - 2] != '/')
	{
        cPathBuff[iLenth - 1] = '/';
	    cPathBuff[iLenth] = '\0';
	}
	else
	{
        cPathBuff[iLenth - 1] = '\0';
	}
	DEBUG_Print("cPathBuff: %s\n",cPathBuff);
	return cPathBuff;
}

/* ����һ��Ŀ¼
    cDirtory: Ŀ¼��
*/
int EnterADirtory(char* cDirtory)
{
    int iError;
    
	iCurPage = 0;
	g_iALLFileDispComplt = 1;
	g_iPageNum = 0;
	SetMemNull();
    /* �ͷ����� */
    FreeFileList();
    
	/* ���浱ǰ����Ŀ¼ */
	memcpy(cCurOprDir,(const void*)cDirtory,strlen(cDirtory));
	cCurOprDir[strlen(cDirtory)]= '\0';

    CleanScreenArea(ptExplorePageVedioMem->ucPixelDatas,120,ptExplorePageVedioMem->iVedioWidth - 1,\
                    0,ptExplorePageVedioMem->iVedioHeight - 1, BLCAK_COLOR);
    iError |= ExploreDirectory(cDirtory);
    iError |= DispOnePage();
    LoadExplorePageToVedioMem();
}

static int ExplorePageButtonAction(int iID)
{
    int iError;
    char cParentDir[MAX_FILE_LENTH];
    switch(iID)
    {
        case 0:
        {
            /* ���� */
            GetParentDirtory(cParentDir);
            EnterADirtory(cParentDir);
        }
        break;
        case 1:
        {
            /* ѡ�� */
            
        }
        break;
        case 2:
        {
            /* ��һҳ */
            PreAndNextPageHandler(GO_PREPAGE);
        }
        break;
        case 3:
        {
            /* ��һҳ */
            /* �����������ʾͼ������� */
            /* ���������û����һҳ��λ����Ϣ */
            if(PreAndNextPageHandler(GO_NEXTPAGE))
            {
	            CleanScreenArea(ptExplorePageVedioMem->ucPixelDatas,120,ptExplorePageVedioMem->iVedioWidth - 1,\
	                            0,ptExplorePageVedioMem->iVedioHeight - 1, BLCAK_COLOR);
	            DispOnePage();
	            LoadExplorePageToVedioMem();
            }
        }
        break;
        default: break;
    }
    return iError;
}

static int ExplorePageGetEvent(void)
{
    int iError;
    int i;
    int iNum = 0;
    int iLenth;
    PT_PageIcon ptCurPageIcon;
	PT_InputEvent ptInputEvent;
    ptInputEvent = (PT_InputEvent)malloc(sizeof(T_InputEvent));
    if(ptInputEvent < 0)
    {
        DEBUG_Print("ptInputEvent malloc failed\n");
        return -1;
    }
    while(1)
    {
	    if(GetInputState(ptInputEvent) == 0)
		{
			if(ptInputEvent->eKeyState == KEY_RELEASE)
			{
			    for(i = 0; i < sizeof(tExplorePageIcon)/sizeof(tExplorePageIcon[0]); i++)
			    {
                    if((ptInputEvent->iXpos >= tExplorePageIcon[i].iXpos) && \
                       (ptInputEvent->iXpos <= tExplorePageIcon[i].iXpos + tExplorePageIcon[i].iWidth) &&\
                       (ptInputEvent->iYpos >= tExplorePageIcon[i].iYpos) &&\
                       (ptInputEvent->iYpos <= tExplorePageIcon[i].iYpos + tExplorePageIcon[i].iHeight))
                    {
                        /* �����ͷ� */
                        iError = ExplorePageButtonAction(i);
                        if(iError < 0)
					    {
					        DEBUG_Print("Error ExplorePageButtonAction\n");
					        return -1;
					    }
                    }
			    }

                /* ��õ�ǰ��ʾҳ���ҳͷָ�룬�Ե�ǰҳ���µ�����ҳ������ж� */
                ptCurPageIcon = ptPageNum[iCurPage];
			    while((ptCurPageIcon != NULL) && (iNum < MAX_ICON_ONE_PAGE))
			    {
                    if((ptInputEvent->iXpos >= ptCurPageIcon->iXpos) && \
                       (ptInputEvent->iXpos <= ptCurPageIcon->iXpos + ptCurPageIcon->iWidth) &&\
                       (ptInputEvent->iYpos >= ptCurPageIcon->iYpos) &&\
                       (ptInputEvent->iYpos <= ptCurPageIcon->iYpos + ptCurPageIcon->iHeight))
                    {
                        DEBUG_Print("%s release, type is %s\n",ptCurPageIcon->cIconName,\
                                    (ptCurPageIcon->eFileType == TYPE_JPG) ? "JPG" : \
                                    ((ptCurPageIcon->eFileType == TYPE_BMP) ? "BMP" : "DIR or OTHER"));
                        if(ptCurPageIcon->eFileType == TYPE_DIR)
                        {
                            /* ����Ŀ¼ */
                            iLenth = strlen(ptCurPageIcon->cIconName);
                            ptCurPageIcon->cIconName[iLenth] = '/';
                            ptCurPageIcon->cIconName[iLenth + 1] = '\0';
                            
                            EnterADirtory(ptCurPageIcon->cIconName);
                            break;    /* ǿ���˳��ٴλ��ҳͷָ�� */
                        }
                        else if(ptCurPageIcon->eFileType == TYPE_JPG)
                        {
                            /* ���ͼƬ */
                            iError = PageRun("browsepage")->PageRun(ptCurPageIcon);
                            if(iError < 0)
                            {
                                DEBUG_Print("Error Run browsepage\n");
                                return -1;
                            }
                        }
                    }
                    ptCurPageIcon = ptCurPageIcon->next;
                    iNum++;
			    }
			    iNum = 0;
			}
		}
    }
    free(ptInputEvent);
    return 0;
}

static int ExplorePageRun(PT_PageIcon ptPageIcon)
{
    int iError;
    iError = ShowExplorePage();
    iError |= LoadExplorePageToVedioMem();
    iError |= ExplorePageGetEvent();
    return iError;
}


T_PageOpr ExplorePageOpr = {
    .name = "explorepage",
    .PageRun = ExplorePageRun,
};

int ExplorePageRegister(void)
{
    return (RegisterPageOpr(&ExplorePageOpr));
}

