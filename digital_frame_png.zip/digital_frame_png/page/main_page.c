#include "config.h"

T_PageOpr MainPageOpr;
static PT_VedioMem ptMainPageVedioMem = NULL;
static int MainPageRun(PT_PageIcon ptPageIcon);

T_PageIcon tMainPageIcon[] = {
    {400 - 256/2, 30, 256, 128, "./icons/browse_mode.bmp",NULL},
    {400 - 256/2, 20+128+30, 256, 128, "./icons/continue_mod.bmp",NULL},
    {400 - 256/2, 20+128+20+128+30, 256, 128, "./icons/interval.bmp",NULL},
};


static int DrawMainPage(PT_VedioMem ptMainPage)
{
    int i;
    int iError;
    for(i = 0; i < sizeof(tMainPageIcon)/sizeof(tMainPageIcon[0]); i++)
    {
        iError |= ShowPicture(ptMainPage,tMainPageIcon[i].iXpos,tMainPageIcon[i].iYpos,tMainPageIcon[i].cIconName,"bmp");
    }

    return iError;
}

static int ShowMainPage(void)
{
	/* ���MainPage �Դ� */
	if((ptMainPageVedioMem = GetVedioMem(MAIN_PAGE_ID)) == NULL)
	{
        DEBUG_Print("Main page get memory failed\n");
        return -1;
	}
	ptMainPageVedioMem->iID = MAIN_PAGE_ID;
	/* ����Դ�Ϊ����������� */
	if(ptMainPageVedioMem->eVedioMemFill == VMF_NFILL)
	{
	    DEBUG_Print("Main page fill data\n");
        if(DrawMainPage(ptMainPageVedioMem) < 0)
        return -1;
        ptMainPageVedioMem->eVedioMemFill = VMF_FILLED;
	}
	return 0;
}

static int LoadMainPageToVedioMem(void)
{
    char* cpVedioMemAddr = NULL;
    cpVedioMemAddr = GetDispVedioMemAddr();
    if(cpVedioMemAddr <= 0)
    {
        DEBUG_Print("GetDispVedioMemAddr Error\n");
        return -1;
    }
    memcpy(cpVedioMemAddr,ptMainPageVedioMem->ucPixelDatas,\
    ptMainPageVedioMem->iVedioHeight * ptMainPageVedioMem->iVedioWidth * 4);
    return 0;
}

static int MainPageButtonAction(int iID)
{
    int iError;
    switch(iID)
    {
        case 0:
        {
            /* button0 */
            iError = PageRun("explorepage")->PageRun(NULL);
        }
        break;
        case 1:
        {
            /* button1 */
            iError = PageRun("autopage")->PageRun(NULL);
        }
        break;
        case 2:
        {
            /* button2 */
            iError = PageRun("intervalpage")->PageRun(NULL);
        }
        break;
        default: break;
    }
    return iError;
}

static int MainPageGetEvent(void)
{
    int iError;
    int i;
	PT_InputEvent ptInputEvent;
    ptInputEvent = (PT_InputEvent)malloc(sizeof(T_InputEvent));
    if(ptInputEvent < 0)
    {
        DEBUG_Print("ptInputEvent malloc failed\n");
        return -1;
    }
    while(1)
    {
	    if(GetInputState(ptInputEvent) == 0)
		{
			if(ptInputEvent->eKeyState == KEY_RELEASE)
			{
			    for(i = 0; i < sizeof(tMainPageIcon)/sizeof(tMainPageIcon[0]); i++)
			    {
                    if((ptInputEvent->iXpos >= tMainPageIcon[i].iXpos) && \
                       (ptInputEvent->iXpos <= tMainPageIcon[i].iXpos + tMainPageIcon[i].iWidth) &&\
                       (ptInputEvent->iYpos >= tMainPageIcon[i].iYpos) &&\
                       (ptInputEvent->iYpos <= tMainPageIcon[i].iYpos + tMainPageIcon[i].iHeight))
                    {
                        /* �����ͷ� */
                        iError = MainPageButtonAction(i);
                        if(iError < 0)
					    {
					        DEBUG_Print("Error MainPageButtonAction\n");
					        return -1;
					    }
                    }
			    }
			}
		}
    }
    free(ptInputEvent);
    return 0;
}

static int MainPageRun(PT_PageIcon ptPageIcon)
{
    int iError;
    iError = ShowMainPage();
    iError |= LoadMainPageToVedioMem();
    iError |= MainPageGetEvent();
    return iError;
}


T_PageOpr MainPageOpr = {
    .name = "mainpage",
    .PageRun = MainPageRun,
};

int MainPageRegister(void)
{
    return (RegisterPageOpr(&MainPageOpr));
}

