#include "config.h"

T_PageOpr BrowsePageOpr;
static PT_VedioMem ptBrowsePageVedioMem = NULL;
PT_PicList ptPicListHead = NULL;
PT_PicList ptPicListPos = NULL; 


static int BrowsePageRun(PT_PageIcon ptPageIcon);

T_PageIcon tBrowsePageIcon[] = {
    {0, 0, 80, 80, "/home/digital/icons/return.bmp",NULL},
    {0, 80, 80, 80, "/home/digital/icons/continue_mod_small.bmp",NULL},
    {0, 160, 80, 80, "/home/digital/icons/zoomin.bmp",NULL},
    {0, 240, 80, 80, "/home/digital/icons/zoomout.bmp",NULL},
    {0, 320, 80, 80, "/home/digital/icons/pre_pic.bmp",NULL},
    {0, 400, 80, 80, "/home/digital/icons/next_pic.bmp",NULL},
};

static void AddPicToList(PT_PicList ptPicNode)
{
    PT_PicList ptTmp = NULL;

    if(!ptPicListHead)
    {
        ptPicListHead = ptPicNode;
        ptPicNode->prev = NULL;
        ptPicNode->next = NULL;
    }
    else
    {
        ptTmp = ptPicListHead;
        while(ptTmp->next)
        {
            ptTmp = ptTmp->next;
        }
        ptTmp->next = ptPicNode;
        ptPicNode->prev = ptTmp;
        ptPicNode->next = NULL;
    }
}

static void FreePicList(void)
{
    PT_PicList ptTemp1 = ptPicListHead;
    PT_PicList ptTemp2 = NULL;
    while(ptTemp1)
    {
        ptTemp2 = ptTemp1->next;
        ptTemp1->prev = NULL;
        ptTemp1->next = NULL;
        free(ptTemp1);
        ptTemp1 = ptTemp2;
    }
    ptPicListHead = NULL;
    ptPicListPos = NULL;
}

static void ShowBrowseList(void)
{
    PT_PicList ptTmp = ptPicListHead;
    DEBUG_Print("BrowseLise:\n");
    DEBUG_Print("pos point: %s\n",ptPicListPos->cpPicName);
    while(ptTmp)
    {
        DEBUG_Print("%s\n",ptTmp->cpPicName);
        ptTmp = ptTmp->next;
    }
}


static int DrawBrowsePage(PT_VedioMem ptBrowsePage)
{
    int i;
    int iError;
    for(i = 0; i < sizeof(tBrowsePageIcon)/sizeof(tBrowsePageIcon[0]); i++)
    {
        iError |= ShowPicture(ptBrowsePage,tBrowsePageIcon[i].iXpos,tBrowsePageIcon[i].iYpos,tBrowsePageIcon[i].cIconName,"bmp");
    }

    return iError;
}

static int ShowBrowsePage(PT_PageIcon ptPageIcon)
{
    int iError;
	/* ���BrowsePage �Դ� */
	if((ptBrowsePageVedioMem = GetVedioMem(BROWSE_PAGE_ID)) == NULL)
	{
        DEBUG_Print("Browse page get memory failed\n");
        return -1;
	}
	ptBrowsePageVedioMem->iID = BROWSE_PAGE_ID;
	/* ����Դ�Ϊ����������� */
	if(ptBrowsePageVedioMem->eVedioMemFill == VMF_NFILL)
	{
	    DEBUG_Print("Browse page fill data\n");
        if(DrawBrowsePage(ptBrowsePageVedioMem) < 0)
        return -1;
        ptBrowsePageVedioMem->eVedioMemFill = VMF_FILLED;
	}

	/* ���һ��ͼƬ���� */
    iError = ShowPicture(ptBrowsePageVedioMem,80,0,ptPageIcon->cIconName,"jpeg");
    if(iError < 0)
    {
        DEBUG_Print("Error ShowPicture, %s\n",__FUNCTION__);
        return -1;
    }
	return 0;
}

static int LoadBrowsePageToVedioMem(void)
{
    char* cpVedioMemAddr = NULL;
    cpVedioMemAddr = GetDispVedioMemAddr();
    if(cpVedioMemAddr <= 0)
    { 
        DEBUG_Print("GetDispVedioMemAddr Error\n");
        return -1;
    }
    memcpy(cpVedioMemAddr,ptBrowsePageVedioMem->ucPixelDatas,\
    ptBrowsePageVedioMem->iVedioHeight * ptBrowsePageVedioMem->iVedioWidth * 4);
    return 0;
}

static int BrowsePageButtonAction(int iID)
{
    int iError;
    switch(iID)
    {
        case 0:
        {
            /* ���� */
            /* Ҫ�ͷ�������Ϊ�ٴν�����׼�� */
            FreePicList();
            iError = PageRun("explorepage")->PageRun(NULL);
        }
        break;
        case 1:
        {
            /* ���� */
            iError = PageRun("autopage")->PageRun(NULL);
        }
        break;
        case 2:
        {
            /* �Ŵ� */
            //iError = PageRun("intervalpage")->PageRun(NULL);
        }
        break;
        case 3:
        {
            /* ��С */
            //iError = PageRun("explorepage")->PageRun(NULL);
        }
        break;
        case 4:
        {
            /* ��һ�� */
            /* ���һ��ͼƬ���� */
            ShowBrowseList();
            if(ptPicListPos == NULL) break;
            if(ptPicListPos->prev)
            {
                ptPicListPos = ptPicListPos->prev;
                DEBUG_Print("picName: %s\n",ptPicListPos->cpPicName);
                //DrawBrowsePage(ptBrowsePageVedioMem);
			    iError = ShowPicture(ptBrowsePageVedioMem,80,0,ptPicListPos->cpPicName,"jpeg");
			    if(iError < 0)
			    {
			        DEBUG_Print("Error ShowPicture, %s\n",__FUNCTION__);
			        return -1;
			    }
			    LoadBrowsePageToVedioMem();
		    }
        }
        break;
        case 5:
        {
            /* ��һ�� */
            /* ���һ��ͼƬ���� */
            ShowBrowseList();
            if(ptPicListPos == NULL) break;
            if(ptPicListPos->next)
            {
                ptPicListPos = ptPicListPos->next;
                DEBUG_Print("picName: %s\n",ptPicListPos->cpPicName);
                //DrawBrowsePage(ptBrowsePageVedioMem);
			    iError = ShowPicture(ptBrowsePageVedioMem,80,0,ptPicListPos->cpPicName,"jpeg");
			    if(iError < 0)
			    {
			        DEBUG_Print("Error ShowPicture, %s\n",__FUNCTION__);
			        return -1;
			    }
			    LoadBrowsePageToVedioMem();
		    }
        }
        break;
        default: break;
    }
    return iError;
}

static int BrowsePageGetEvent(void)
{
    int iError;
    int i;
	PT_InputEvent ptInputEvent;
    ptInputEvent = (PT_InputEvent)malloc(sizeof(T_InputEvent));
    if(ptInputEvent < 0)
    {
        DEBUG_Print("ptInputEvent malloc failed\n");
        return -1;
    }
    while(1)
    {
	    if(GetInputState(ptInputEvent) == 0)
		{
			if(ptInputEvent->eKeyState == KEY_RELEASE)
			{
			    for(i = 0; i < sizeof(tBrowsePageIcon)/sizeof(tBrowsePageIcon[0]); i++)
			    {
                    if((ptInputEvent->iXpos >= tBrowsePageIcon[i].iXpos) && \
                       (ptInputEvent->iXpos <= tBrowsePageIcon[i].iXpos + tBrowsePageIcon[i].iWidth) &&\
                       (ptInputEvent->iYpos >= tBrowsePageIcon[i].iYpos) &&\
                       (ptInputEvent->iYpos <= tBrowsePageIcon[i].iYpos + tBrowsePageIcon[i].iHeight))
                    {
                        /* �����ͷ� */
                        iError = BrowsePageButtonAction(i);
                        if(iError < 0)
					    {
					        DEBUG_Print("Error BrowsePageButtonAction\n");
					        return -1;
					    }
                    }
			    }
			}
		}
    }
    free(ptInputEvent);
    return 0;
}

/* ��ȡ�ļ������� */
void ExtractDirtory(char* cpPath, char* cDir)
{
    int iLenth = strlen(cpPath);
    int iPos = iLenth;
    int iCopySize = 0;
    while(iPos--) 
    {
        if(cpPath[iPos] == '/')
            break;
    }
    iCopySize = iPos + 1;
    strncpy(cDir, cpPath, iCopySize);
    cDir[iCopySize] = '\0';
}

/* ��ȡͼƬ�����ļ��в����ӵ�ǰ�ļ����������ļ������� */
static int AddCurDirPicToList(PT_PageIcon ptPageIcon)
{
    PT_PicList ptPic; 
    char cCommand[MAX_FILE_LENTH + 1] = {'l','s',' ','\0'};
    char cpTemp[MAX_FILE_LENTH + 1];
    FILE* fp;

    /* ��ǰ��ʾͼƬ���ڵ�Ŀ¼ */
    ExtractDirtory(ptPageIcon->cIconName, cpTemp);
    strncat(cCommand,cpTemp,strlen(cpTemp));        // ls xxx/xxx/
    strncat(cCommand,"*.jpg",5);                    // ls xxx/xxx/*.jpg
    DEBUG_Print("command: %s\n",cCommand);
    
    fp = popen(cCommand, "r");   
	if(fp == NULL)
	{
	    DEBUG_Print("Error popen\n");
	    return -1;
	}
    /* ���Ҫ��ʾͼƬ���ļ��� */
	while(fgets(cpTemp, MAX_FILE_LENTH, fp) != NULL)
	{
	    /* ȥ������Ļ��з� */
		cpTemp[strlen(cpTemp) - 1] = '\0';
		DEBUG_Print("file name: %s\n",cpTemp);
		
	    ptPic = (PT_PicList)malloc(sizeof(T_PicList));
	    if(ptPic == NULL)
	    {
	        DEBUG_Print("Error malloc ptPic\n");
	        return -1;
	    }
	    strncpy(ptPic->cpPicName,cpTemp,strlen(cpTemp));
	    ptPic->cpPicName[strlen(cpTemp)] = '\0';
	    if(strcmp(ptPageIcon->cIconName,cpTemp) == 0)
	    {
            ptPicListPos = ptPic;
            DEBUG_Print("pos is %s\n",ptPicListPos->cpPicName);
	    }
	    AddPicToList(ptPic);
	}
    pclose(fp);
    DEBUG_Print("AddCurDirPicToList END\n");
    return 0;
}

static int BrowsePageRun(PT_PageIcon ptPageIcon)
{
    int iError;
    iError = ShowBrowsePage(ptPageIcon);
    iError |= LoadBrowsePageToVedioMem();
    iError |= AddCurDirPicToList(ptPageIcon);
    iError |= BrowsePageGetEvent();
    return iError;
}


T_PageOpr BrowsePageOpr = {
    .name = "browsepage",
    .PageRun = BrowsePageRun,
};

int BrowsePageRegister(void)
{
    return (RegisterPageOpr(&BrowsePageOpr));
}


