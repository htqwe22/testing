#ifndef _FONT_MANAGER_H
#define _FONT_MANAGER_H

typedef struct FontBitMap{
    int iCurOriginX;
    int iCurOriginY;
    unsigned char* pucBitMap;
    int iPitch;
    int iWidth;
    int iHeight;
}T_FontBitMap, *PT_FontBitMap;

typedef struct FontOpr{
    char* name;
    int(*FontInit)(char* pcFile);
    int(*GetFontData)(char* pucCode, PT_FontBitMap ptBitMap);
    struct FontOpr* next;
}T_FontOpr, *PT_FontOpr;


int RegisterFontOpr(PT_FontOpr ptFontOpr);
PT_FontOpr GetFontFile(char* cName);
int FontInit(void);
int AsciiFontRegister(void);
int GBKFontRegister(void);
void ShowString(char* cDispMem, char* string, int iX, int iY,unsigned int iColor);


#endif
