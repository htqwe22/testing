#ifndef _CONFIG_H
#define _CONFIG_H
#include "disp_manager.h"
#include "encode_manager.h"
#include "font_manager.h"
#include "input_manager.h"
#include "page_manager.h"
#include "pic_manager.h"
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <linux/fb.h>
#include <sys/mman.h>
#include <string.h>
#include <sys/ioctl.h>

#define FALSE     0
#define TRUE      1

#define MAX_FILE_LENTH   100    /* �ļ�����󳤶� */
#define MAX_ICON_ONE_PAGE 20
#define FILE_NAME_SIZE    10
#define DISP_DEVICE "fb"
#define FB_FILE     "/dev/fb0"
#define HZK_FILE    "HZK16"
#define BLCAK_COLOR COLOR_BLACK
#define FONT_COLOR  COLOR_GREE

#define DEFAULT_DISP_DEVICE   "fb"
#define DEFAULT_ENCODE        "ascii"
#define DEFAULT_INPUT_DEVICE  "touchscreen"
#define DEFAULT_DIR           "./"


#define COLOR_RED   0xFF0000
#define COLOR_GREE  0x00FF00
#define COLOR_BLUE  0x0000FF
#define COLOR_BLACK 0x0
#define COLOR_WRITE 0xFFFFFF
#define SKY_BLUE    0xAE81E6
 
#define DEBUG_Print    printf
//#define DEBUG_Print(...)

#endif
