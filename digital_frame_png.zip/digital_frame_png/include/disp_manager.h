#ifndef _DISP_MANAGER_H
#define _DISP_MANAGER_H


typedef struct DispOpr{
    char* name;
    int iXres;
    int iYres;
    char* cpVedioMemAddr;
    int(*ShowPixel)(int iPenX, int iPenY, unsigned int dwcolor);
    int(*DispDeviceInit)(void);
    void(*ScreenClear)(unsigned int udwcolor);
    struct DispOpr* next;
}T_DispOpr,*PT_DispOpr;


typedef enum{
    VMS_FREE = 0,
    VMS_USED,
}E_VideoMemState;


typedef enum{
    VMF_NFILL = 0,
    VMF_FILLED,
}E_VideoMemFill;

typedef struct VedioMem{
    int iID;
    int iVedioWidth;
    int iVedioHeight;
    E_VideoMemState eVedioMemState;         //�Ƿ�ռ��
    E_VideoMemFill eVedioMemFill;           //����ڴ������Ƿ����������
    unsigned char* ucPixelDatas;            //ָ��һ���ڴ�
    struct VedioMem *next;
}T_VedioMem, *PT_VedioMem;


int RegisterDispOpr(PT_DispOpr ptDispOpr);
PT_DispOpr SlectDispDevice(char* cName);
int FBInit(void);
int FBRegister(void);
int AllocVedioMem(int iNum);
PT_VedioMem GetVedioMem(int iID);
void PutVedioMem(PT_VedioMem ptVedioMem);
PT_DispOpr DefaultDispDeviceInit(void);
int GetDispResolution(int *Xres, int *Yres);
char* GetDispVedioMemAddr(void);
void ClearDefauleScreen(int iColor);
unsigned short rgb888_to_rgb565(unsigned int rgb);
int CleanScreenArea(char* cpMemAddr, int iXStart, int iXEnd, int iYStart, int iYEnd, unsigned int uColor);



#endif
