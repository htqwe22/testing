#ifndef _PIC_MANAGER_H
#define _PIC_MANAGER_H
#include <stdio.h>
#include "disp_manager.h"

typedef struct PicOpr{
    char* name;
    int(*DispPic)(PT_VedioMem ptVedioMem, int iX, int iY, char* cpPic);
    struct PicOpr* next;
}T_PicOpr, *PT_PicOpr;

typedef struct BmpInfo{
	unsigned short udID;           //0 1
	unsigned int udwFileSize;      // 2 3 4 5 
	unsigned int udwReserved;      //6 7 8 9
	unsigned int udwOffset;        //10 11 12 13
	unsigned int udStructSize;     //14 15 16 17
	unsigned int udwFileWidth;     //18 19 20 21
	unsigned int udwFileHeight;    //22 23 24 25
	unsigned short udPlanes;       //26 27
	unsigned short udBitCount;     //28 29
	unsigned int udwBitCompression;//30 31 32 33
	unsigned int udwSizeImage;     //34 35 36 37
	unsigned int udwXPelsPerMeter; //38 39 40 41
	unsigned int udwYPelsPerMeter; //42 43 44 45
	unsigned int udwClrUsed;       //46 47 48 49
	unsigned int udwClrImportant;  //50 51 52 53
}__attribute((packed)) T_BMPINFO, *PT_BMPINFO;//����С�ֽڶ���


int BmpRegister(void);
int RegisterPicOpr(PT_PicOpr ptPicOpr);
int ShowPicture(PT_VedioMem ptVedioMem, int iX, int iY, char* cpPicName, char* cpPicFormat);
int PicInit(void);
void ShowPicList(void);
int JpegRegister(void);

int check_if_png(char *file_name, FILE **fp);
int read_png(char* filename, char IsDoAlphaBlend);





#endif
