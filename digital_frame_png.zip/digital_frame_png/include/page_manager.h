#ifndef _PAGE_MANAGER_H
#define _PAGE_MANAGER_H

#define GO_PREPAGE      1
#define GO_NEXTPAGE     2

typedef enum{
    MAIN_PAGE_ID = 1,
    INTERVAL_PAGE_ID,
    AUTO_PAGE_ID,
    AUTO_PRE_PAGE_ID,
    AUTO_NEXT_PAGE_ID,
    EXPLORE_PAGE_ID,
    BROWSE_PAGE_ID,
}E_PAGE_ID;

typedef enum{
    TYPE_DIR = 1,
    TYPE_JPG,
    TYPE_BMP,
    TYPE_OTHER,
}E_FILE_TYPE;

typedef struct PicList{
    char cpPicName[100];
    struct PicList* prev;
    struct PicList* next;
}T_PicList, *PT_PicList;

typedef struct PageIcon{
    int iXpos;
    int iYpos;
    int iWidth;
    int iHeight;
    char cIconName[100];
    int(*CallBack)(void);
    E_FILE_TYPE eFileType;
    struct PageIcon *next;
}T_PageIcon, *PT_PageIcon;

typedef struct PageOpr{
    char* name;
    int(*PageRun)(PT_PageIcon ptPageIcon);

    //struct PageOpr* prev;
    struct PageOpr* next;
}T_PageOpr, *PT_PageOpr;


int RegisterPageOpr(PT_PageOpr ptPageOpr);
PT_PageOpr PageRun(char* cpPageName);
int MainPageRegister(void);
int PageInit(void);
int IntervPageRegister(void);
int AutoPageRegister(void);
int GetInervalTime(void);
int ExplorePageRegister(void);
int BrowsePageRegister(void);




#endif
