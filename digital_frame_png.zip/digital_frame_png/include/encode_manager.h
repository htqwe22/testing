#ifndef _ENCODE_MANAGER_H
#define _ENCODE_MANAGER_H
#include "encode_manager.h"
#include "font_manager.h"


typedef struct EncodeOpr{
    char* name;
    PT_FontOpr ptFontListHead;
    int(*IsSupport)(char* pucFileHead);
    int(*GetEncodeFromBuf)(char* pucFileStart, char* pucEndOfTheFile, char* pucCodeBuff);
    struct EncodeOpr* next;
}T_EncodeOpr, *PT_EncodeOpr;

int RegisterEncodeOpr(PT_EncodeOpr ptAsciiOpr);
int AddFontToEncodeList(PT_EncodeOpr ptEncodeOpr, PT_FontOpr ptFontOpr);
PT_EncodeOpr SelectEncode(char* pucFileHead);
int EncodeInit(void);
int AsciiEncodeRegister(void);
PT_EncodeOpr DefaultEncodeInit(void);
PT_EncodeOpr GetDefaultEncode(void);





#endif
