#ifndef _INPUT_MANAGER_H
#define _INPUT_MANAGER_H
#include <pthread.h>

#define TYPE_TOUCHSCREEN     0
#define TYPE_STDIN           1

#define VALUE_UP             0
#define VALUE_DOWN           1
#define VALUE_EXIT           2

typedef enum{
    KEY_RELEASE = 0,
    KEY_PRESSED,
}E_KeyState;

typedef struct InputEvent{
    int iXpos;
    int iYpos;
    E_KeyState eKeyState;
    int iInputType;
    int iInputValue;
}T_InputEvent, *PT_InputEvent;


typedef struct InputOpr{
    char* name;
    int iFd;
    pthread_t pTid;
    int(*InputDeviceInit)(void);
    void(*InputDeviceExit)(void);
    int(*GetInputCode)(PT_InputEvent ptInputEvent);
    struct InputOpr *next;
}T_InputOpr, *PT_InputOpr;

int TouchScreenRegister(void);
int RegisterInputDevice(PT_InputOpr ptInputOpr);
int AllInputDeviceInit(void);
int GetInputState(PT_InputEvent ptInputEvent);
int InputInit(void);
void ShowInputList(void);
int StdinRegister(void);
void AllInputDeviceExit(void);
int DefaultInputDeviceInit(void);
int IntervPageRegister(void);





#endif
