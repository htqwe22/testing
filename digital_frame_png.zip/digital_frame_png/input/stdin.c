#include "input_manager.h"
#include "config.h"
#include <termios.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/select.h>

static T_InputOpr StdinOpr;

int StdinInit(void)
{
    struct termios tTTYState;
 
    //get the terminal state
    tcgetattr(STDIN_FILENO, &tTTYState);
 
    //turn off canonical mode
    tTTYState.c_lflag &= ~ICANON;
    //minimum of number input read.
    tTTYState.c_cc[VMIN] = 1;   /* ��һ������ʱ�����̷��� */

    //set the terminal attributes.
    tcsetattr(STDIN_FILENO, TCSANOW, &tTTYState);

	StdinOpr.iFd = STDIN_FILENO;

	return 0;    
}
void StdinExit(void)
{
    struct termios tTTYState;
 
    //get the terminal state
    tcgetattr(STDIN_FILENO, &tTTYState);
 
    //turn on canonical mode
    tTTYState.c_lflag |= ICANON;
	
    //set the terminal attributes.
    tcsetattr(STDIN_FILENO, TCSANOW, &tTTYState);	
}

int StdinGetInputCode(PT_InputEvent ptInputEvent)
{
    char c = 0;

    DEBUG_Print("%s %d",__FUNCTION__,__LINE__);
    
    ptInputEvent->iInputType = TYPE_STDIN;
    c = fgetc(stdin);
    switch(c)
    {
        case 'u':
        {
            ptInputEvent->iInputValue = VALUE_UP;
        }
        break;
        case 'n':
        {
            ptInputEvent->iInputValue = VALUE_DOWN;
        }
        break;
        case 'q':
        {
            ptInputEvent->iInputValue = VALUE_EXIT;
        }
        break;
    }
    return 0;
}


#if 0
int StdinGetInputCode(PT_InputEvent ptInputEvent)
{
    char c = 0;
    fd_set StdinReadFd;
    struct timeval tStdinVal;
    FD_ZERO(&StdinReadFd);
    FD_SET(STDIN_FILENO,&StdinReadFd);
    
    tStdinVal.tv_sec = 0;
    tStdinVal.tv_usec = 0;

    DEBUG_Print("%s\n %d",__FUNCTION__,__LINE__);
    
    if(select(STDIN_FILENO + 1,&StdinReadFd,NULL,NULL,&tStdinVal) < 0)
    {
        DEBUG_Print("select failed %s\n",__FUNCTION__);
        return -1;
    }
    if(FD_ISSET(STDIN_FILENO,&StdinReadFd))
    {
        ptInputEvent->iInputType = TYPE_STDIN;
        DEBUG_Print("fd is set %s\n",__FUNCTION__);
        c = fgetc(stdin);
        switch(c)
        {
            case 'u':
            {
                ptInputEvent->iInputValue = VALUE_UP;
            }
            break;
            case 'n':
            {
                ptInputEvent->iInputValue = VALUE_DOWN;
            }
            break;
            case 'q':
            {
                ptInputEvent->iInputValue = VALUE_EXIT;
            }
            break;
        }
    }
    else
    {
        return -1;
    }
    return 0;
}
#endif


static T_InputOpr StdinOpr = {
    .name = "stdin",
    .InputDeviceInit = StdinInit,
    .InputDeviceExit = StdinExit,
    .GetInputCode = StdinGetInputCode,
};

int StdinRegister(void)
{
    return (RegisterInputDevice(&StdinOpr));
}



