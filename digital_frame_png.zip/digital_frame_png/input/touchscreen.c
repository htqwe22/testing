#include "input_manager.h"
#include "config.h"
#include "tslib.h"

static struct tsdev *tTsdev;
static T_InputOpr TouchScreenOpr;
static int DispResX, DispResY;

static int TouchScreenInit(void)
{
    char* pcTsDevice = NULL;
    if ((pcTsDevice = getenv("TSLIB_TSDEVICE")) == NULL) 
    {
        pcTsDevice = strdup ("/dev/input/event0");
    }
    
    if(tTsdev < 0)
    {
        DEBUG_Print("malloc tTsdev failed\n");
    }
    tTsdev = ts_open (pcTsDevice, 0);
    if (!tTsdev) 
    {
        DEBUG_Print("open ts device failed\n");
        return -1;
    }
    if (ts_config(tTsdev)) 
    {
        DEBUG_Print("ts_config failed\n");
        return -1;
    }
    TouchScreenOpr.iFd = ts_fd(tTsdev);
    GetDispResolution(&DispResX,&DispResY);
    DEBUG_Print("TouchScreenInit\n");
    return 0;
}

void TouchScreenExit(void)
{
    
}

static Out500Ms(struct timeval*	tPrev, struct timeval* tNow)
{
    int PreMs, NowMs;
    PreMs = tPrev->tv_sec * 1000 + tPrev->tv_usec / 1000;
    NowMs = tNow->tv_sec * 1000 + tNow->tv_usec / 1000;
    return ((NowMs - PreMs) > 500);
}
static int TouchScreenGetInputCode(PT_InputEvent ptInputEvent)
{
    static E_KeyState iPenState = KEY_RELEASE;
    struct ts_sample tsSamp;
    struct timeval	tTv;
    int ret = 0;
    ret = ts_read(tTsdev, &tsSamp, 1);
    if(ret < 0)
    {
        DEBUG_Print("ts read failed\n");
        return -1;
    }
    if(ret != 1)
        return -1;
    
    //DEBUG_Print("%ld.%06ld: %6d %6d %6d\n", tsSamp.tv.tv_sec, tsSamp.tv.tv_usec,
	//		tsSamp.x, tsSamp.y, tsSamp.pressure);
    if((tsSamp.pressure) && (iPenState == KEY_RELEASE))
    {
	    if(Out500Ms(&tTv,&tsSamp.tv))
	    {
	        tTv = tsSamp.tv;
	        /* ����һ�ΰ�����Ϣ */
	        ptInputEvent->iXpos = tsSamp.x;
	        ptInputEvent->iYpos = tsSamp.y;
	        ptInputEvent->eKeyState = KEY_PRESSED;
            iPenState = KEY_PRESSED;
	        
			return 0;
		}
		else
		{
	        return -1;
		}
    }
    else if((tsSamp.pressure) == 0)  /* �������ͷ� */
    {
        ptInputEvent->iXpos = tsSamp.x;
	    ptInputEvent->iYpos = tsSamp.y;
	    ptInputEvent->eKeyState = KEY_RELEASE;
	    iPenState = KEY_RELEASE;
	    return 0;
    }
    else
    {
        return -1;
    }
    return 0;
}



static T_InputOpr TouchScreenOpr = {
    .name = "touchscreen",
    .InputDeviceInit = TouchScreenInit,
    .InputDeviceExit = TouchScreenExit,
    .GetInputCode = TouchScreenGetInputCode,
};

int TouchScreenRegister(void)
{
    return (RegisterInputDevice(&TouchScreenOpr));
}

