#include "input_manager.h"
#include "config.h"
#include <sys/select.h>
#include <pthread.h>


static PT_InputOpr ptInputOprHead = NULL;
static fd_set fdInputSet;
static int iMaxFd = 0;
static T_InputEvent g_tInputEvent;


static pthread_mutex_t pMutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t pCond = PTHREAD_COND_INITIALIZER;


int RegisterInputDevice(PT_InputOpr ptInputOpr)
{
    PT_InputOpr ptTmp = NULL;
    if(!ptInputOpr)
        return -1;
    /* �������Ϊ�� */
    if(!ptInputOprHead)
    {
        ptInputOprHead = ptInputOpr;
        ptInputOpr->next = NULL;
    }
    else
    {
        ptTmp = ptInputOprHead;
        while(ptTmp->next)
        {
            ptTmp = ptTmp->next;
        }
        ptTmp->next = ptInputOpr;
        ptInputOpr->next = NULL;
    }
    return 0;    
}

void ShowInputList(void)
{
    PT_InputOpr ptTmp = ptInputOprHead;
    while(ptTmp)
    {
        DEBUG_Print("%s %2s\n",__FUNCTION__,ptTmp->name);
        ptTmp = ptTmp->next;
    }
}

int InputInit(void)
{
    int Error = 0;
    Error = TouchScreenRegister();
    Error |= StdinRegister();
    return Error;
}
#if 0
int AllInputDeviceInit(void)
{
    PT_InputOpr ptTmp = ptInputOprHead;
    FD_ZERO(&fdInputSet);
    while(ptTmp)
    {
        if((ptTmp->InputDeviceInit()) < 0)
            return -1;
        FD_SET(ptTmp->iFd,&fdInputSet);
        if(iMaxFd < ptTmp->iFd)
            iMaxFd = ptTmp->iFd;
        ptTmp = ptTmp->next;
    }
    return 0;    
}
#endif

void *InputEventThreadFunc(void* arg)
{
    T_InputEvent tInputEvent;
    int (*GetInputEventCode)(PT_InputEvent ptInputEvent);
    GetInputEventCode = (int (*)(PT_InputEvent))arg;
    
    while(1)
    {
        if(0 == GetInputEventCode(&tInputEvent))
        {
            pthread_mutex_lock(&pMutex);
            g_tInputEvent= tInputEvent;
            pthread_cond_signal(&pCond);
            pthread_mutex_unlock(&pMutex);
        }
    }
    pthread_exit(0);
}

int AllInputDeviceInit(void)
{
    PT_InputOpr ptTmp = ptInputOprHead;
    while(ptTmp)
    {
        if((ptTmp->InputDeviceInit()) < 0)
            return -1;
        pthread_create(&ptTmp->pTid, NULL, InputEventThreadFunc, ptTmp->GetInputCode);
        ptTmp = ptTmp->next;
    }
    return 0;    
}


void AllInputDeviceExit(void)
{
    PT_InputOpr ptTmp = ptInputOprHead;
    while(ptTmp)
    {
		ptTmp->InputDeviceExit();
        ptTmp = ptTmp->next;
    }
}

int DefaultInputDeviceInit(void)
{
    PT_InputOpr ptTmp = ptInputOprHead;
    while(ptTmp)
    {
        if(strcmp(ptTmp->name,DEFAULT_INPUT_DEVICE) == 0)
        {
            if((ptTmp->InputDeviceInit()) < 0)
            return -1;
            pthread_create(&ptTmp->pTid, NULL, InputEventThreadFunc, ptTmp->GetInputCode);
        }
        ptTmp = ptTmp->next;
    }
    return 0;    
}


/* ���߳�ʵ��*/
int GetInputState(PT_InputEvent ptInputEvent)
{
    pthread_mutex_lock(&pMutex);
    pthread_cond_wait(&pCond, &pMutex);
    *ptInputEvent = g_tInputEvent;
    pthread_mutex_unlock(&pMutex);
}

#if 0
/* select ʵ��*/
int GetInputState(PT_InputEvent ptInputEvent)
{
    PT_InputOpr ptTmp = ptInputOprHead;
    struct timeval tInputTime;
    fd_set ReadFd = fdInputSet;   /* �����ʼfd_set*/
    
    tInputTime.tv_sec = 0;
    tInputTime.tv_usec = 0;

    if(select(iMaxFd + 1, &ReadFd, NULL, NULL,NULL) < 0)
    {
        DEBUG_Print("select failed\n");
        return -1;
    }
    while(ptTmp)
    {
        if(FD_ISSET(ptTmp->iFd,&ReadFd))
        {
            if((ptTmp->GetInputCode(ptInputEvent)) < 0)
                return -1;
            return 0;
        }
        ptTmp = ptTmp->next;
    }
}
#endif

