#include "config.h"

static int FBShowPixel(int iPenX, int iPenY, unsigned int dwcolor);
static int FBDeviceInit(void);
static void FBScreenClear(unsigned int udwcolor);

static int g_Fbfd;
static char* g_LcdMem;
static unsigned int g_udwScreenSize;

static T_DispOpr FB_DispOPr = {
    .name = "fb",
    .DispDeviceInit = FBDeviceInit, 
    .ShowPixel = FBShowPixel,
    .ScreenClear = FBScreenClear,
};

static int FBShowPixel(int iPenX, int iPenY, unsigned int dwcolor)
{
    if((iPenX < 0) || (iPenX > FB_DispOPr.iXres) || (iPenY < 0) || (iPenY > FB_DispOPr.iYres))
        return -1;
    unsigned int location = (iPenX + iPenY * FB_DispOPr.iXres) * 4;
    *((unsigned int*)(g_LcdMem + location)) = dwcolor;    //rgb888_to_rgb565(dwcolor);
    return 0;
}

static void FBScreenClear(unsigned int udwcolor)
{
    memset(g_LcdMem,udwcolor,g_udwScreenSize);
}

static int FBDeviceInit(void)
{
    int ret = 0;
	struct fb_var_screeninfo var;

	
    /* open device file */
    g_Fbfd = open(FB_FILE,O_RDWR);
    if(g_Fbfd == -1)
    {
        DEBUG_Print("Error: can't open /dev/fb0.\n");
        return -1;
    }

    /* get screen information */
    ret = ioctl(g_Fbfd,FBIOGET_VSCREENINFO,&var);
    if(ret == -1)
    {
        DEBUG_Print("Error: can't reading screen information.\n");
        return -1;
    }
    DEBUG_Print("screen size is xres = %d,yres = %d,bits_per_pixel = %d\n",var.xres,var.yres,var.bits_per_pixel);

    /* figure out the size of screen in bytes */
    g_udwScreenSize = var.xres * var.yres * (var.bits_per_pixel / 8);
    
    /* map the device to memory */
    g_LcdMem = (char *)mmap(NULL,g_udwScreenSize,PROT_WRITE | PROT_READ,MAP_SHARED,g_Fbfd,0);
    if(!g_LcdMem)
    {
        DEBUG_Print("Error can't map the device to memory.\n");
        return -1;
    }

    FB_DispOPr.iXres = var.xres;
    FB_DispOPr.iYres = var.yres;
    FB_DispOPr.cpVedioMemAddr = g_LcdMem;

    return ret;
}


int FBRegister(void)
{
    return RegisterDispOpr(&FB_DispOPr);
}

