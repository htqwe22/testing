#include "config.h"


static PT_DispOpr ptDispOprHead = NULL;
static PT_VedioMem ptVedioMemHead = NULL;
static PT_DispOpr ptDefaultDispDevice = NULL;

int RegisterDispOpr(PT_DispOpr ptDispOpr)
{
    PT_DispOpr ptTmp;
    /* �������Ϊ�� */
    if(!ptDispOprHead)
    {
        ptDispOprHead = ptDispOpr;
        ptDispOpr->next = NULL;
    }
    else
    {
        ptTmp = ptDispOprHead;
        while(ptTmp->next)
        {
            ptTmp = ptTmp->next;
        }
        ptTmp->next = ptDispOpr;
        ptDispOpr->next = NULL;
    }
    return 0;
}

PT_DispOpr SlectDispDevice(char* cName)
{
    PT_DispOpr ptTmp = ptDispOprHead;
    while(ptTmp)
    {
        if(strcmp(ptTmp->name,cName) == 0)
        {
            return ptTmp;
        }
        ptTmp = ptTmp->next;
    }
    return ((PT_DispOpr)-1);
}

PT_DispOpr DefaultDispDeviceInit(void)
{
    ptDefaultDispDevice = SlectDispDevice(DEFAULT_DISP_DEVICE);
    if(ptDefaultDispDevice == (PT_DispOpr)-1)
    {
        DEBUG_Print("select defalut disp device failed\n");
        return (PT_DispOpr)-1;
    }
    DEBUG_Print("%s,%s\n",__FUNCTION__, ptDefaultDispDevice->name);
    ptDefaultDispDevice->DispDeviceInit();
    ptDefaultDispDevice->ScreenClear(BLCAK_COLOR);
    return ptDefaultDispDevice;
}

/* ����Դ�ĵ�ַ */
char* GetDispVedioMemAddr(void)
{
    return (ptDefaultDispDevice->cpVedioMemAddr);
}

void ClearDefauleScreen(int iColor)
{
    ptDefaultDispDevice->ScreenClear(iColor);
}

int GetDispResolution(int *Xres, int *Yres)
{
    if(!ptDefaultDispDevice)
        return -1;
    *Xres = ptDefaultDispDevice->iXres;
    *Yres = ptDefaultDispDevice->iYres;
    return 0;
}


int CleanScreenArea(char* cpMemAddr, int iXStart, int iXEnd, int iYStart, int iYEnd, unsigned int uColor)
{
    int iX, iY;
    int iXres, iYres;
    unsigned int location;
    GetDispResolution(&iXres,&iYres);
    for(iY = iYStart; iY < iYEnd; iY++)
    {
        for(iX = iXStart; iX < iXEnd; iX++)
        {
            location = iX * 4 + iY * iXres* 4;
	        *((unsigned int*)(cpMemAddr + location)) = uColor;    //rgb888_to_rgb565(uColor);
        }
    }
}


int AllocVedioMem(int iNum)
{
    int iResX = 0, iResY = 0;
    PT_VedioMem ptTmp = NULL;
    GetDispResolution(&iResX, &iResY);
    //DEBUG_Print("%s,%d\n",__FUNCTION__,(iResX * iResY * 2));
    while(iNum--)
    {
        ptTmp = (PT_VedioMem)malloc(sizeof(T_VedioMem) + iResX * iResY * 4);
	    if(ptTmp < 0)
	    {
	        DEBUG_Print("vedioMem malloc Error\n");
	        return -1;
	    }
	    ptTmp->ucPixelDatas = (unsigned char*)(ptTmp + 1);
	    ptTmp->iID = 0;
	    ptTmp->iVedioWidth = iResX;
	    ptTmp->iVedioHeight = iResY;
	    ptTmp->eVedioMemState = VMS_FREE;
	    ptTmp->eVedioMemFill = VMF_NFILL;

	    /* �������� */
	    ptTmp->next = ptVedioMemHead;
	    ptVedioMemHead = ptTmp;
    }
    return 0;
}

PT_VedioMem GetVedioMem(int iID)
{
    PT_VedioMem ptTmp = ptVedioMemHead;
    /* 1. ���ȷ���һ�����е�ID��ͬ��*/
    while(ptTmp)
    {
        if((ptTmp->iID == iID) && (ptTmp->eVedioMemState == VMS_FREE))
        {
            return ptTmp;
        }
        ptTmp = ptTmp->next;
    }
    
    ptTmp = ptVedioMemHead;
    /* 2. ����һ�����е�����Ϊ�յ�*/
    while(ptTmp)
    {
        if((ptTmp->eVedioMemState == VMS_FREE) && (ptTmp->eVedioMemFill == VMF_NFILL))
        {
            return ptTmp;
        }
        ptTmp = ptTmp->next;
    }

    ptTmp = ptVedioMemHead;
    /*3. ����һ�����е�*/
    while(ptTmp)
    {
        if(ptTmp->eVedioMemState == VMS_FREE)
        {
            return ptTmp;
        }
        ptTmp = ptTmp->next;
    }
    
    /* û�з��䵽�ڴ�*/
    return NULL;
}

/* �ͷ�һ���ڴ�*/
void PutVedioMem(PT_VedioMem ptVedioMem)
{
    ptVedioMem->eVedioMemState = VMS_FREE;
    if(ptVedioMem->iID == -1)
    {
        ptVedioMem->eVedioMemFill = VMF_FILLED;
    }
}

unsigned short rgb888_to_rgb565(unsigned int rgb)
{
    unsigned short r = 0,g = 0,b = 0;
    b = (rgb >> 16) & 0x00FF;
    g = (rgb >> 8) & 0x00FF;
    r = rgb & 0x00FF;
    return (unsigned short)(((r << 8) & 0xF800) | \
                ((g << 3) & 0x7E0)   | \
                ((b >> 3)));
}


int FBInit(void)
{
    return(FBRegister());
}
