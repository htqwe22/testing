#include "config.h"

FILE *fp;

int main(int argc,char** argv)
{
    int iError;
    PT_InputEvent ptInputEvent;
    if(argc < 2)
    {
        DEBUG_Print("Usage: %s <filename>\n",argv[0]);
        return 0;
    }
    
    FBInit();
    DEBUG_Print("FBInit success\n");
    FontInit();
    DEBUG_Print("FontInit success\n");
    
    EncodeInit();
    DEBUG_Print("EncodeInit success\n");
    if(InputInit() < 0)
    {
        DEBUG_Print("InputInit failed\n");
        return -1;
    }

    /* Ĭ���豸��ʼ�� */
    DefaultDispDeviceInit();
    DefaultEncodeInit();
    ShowInputList();
    DEBUG_Print("ShowInputList success\n");

    iError = PicInit();
    if(iError < 0)
    {
        DEBUG_Print("Error PicInit\n");
        return -1;
    }
    ShowPicList();
    iError = PageInit();
    if(iError < 0)
    {
        DEBUG_Print("Error PageInit\n");
        return -1;
    }

    iError = DefaultInputDeviceInit();
    if(iError < 0)
    {
        DEBUG_Print("AllInputDeviceInit failed\n");
        return -1;
    }
    iError = AllocVedioMem(10);
    if(iError < 0)
    {
        DEBUG_Print("Error AllocVedioMem\n");
        return -1;
    }

    read_png(argv[1], 1);
   
    if(argc > 2)
        read_png(argv[2], 1);
#if 0   	
    /* ��ʾ��ҳ�� */
    iError = PageRun("mainpage")->PageRun(NULL);
    if(iError < 0)
    {
        DEBUG_Print("Error PageRun\n");
        return -1;
    }
  
	while(1)
	{
	    ptInputEvent = (PT_InputEvent)malloc(sizeof(T_InputEvent));
	    if(ptInputEvent < 0)
	    {
            DEBUG_Print("ptInputEvent malloc failed\n");
            return -1;
	    }
		if(GetInputState(ptInputEvent) == 0)
		{
			if(ptInputEvent->eKeyState == KEY_PRESSED)
			    DEBUG_Print("Key Pressed\n");
			else if(ptInputEvent->eKeyState == KEY_RELEASE)
			    DEBUG_Print("Key Release\n");
		}
	}
	free(ptInputEvent);
#endif
    return 0;
}


