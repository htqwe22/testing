#include "png.h"
#include "config.h"

#define PNG_BYTES_TO_CHECK 4
//#define entire  1
//#define hilevel 1

typedef struct png_rgb
{
    unsigned int height;
    unsigned int width;
    unsigned int xPos;
    unsigned int yPos;
    unsigned char R;
    unsigned char G;
    unsigned char B;
    unsigned char A;
}T_PNG_INFO,*PT_PNG_INFO;

static void GetBlkRGB(PT_PNG_INFO ptRgb)
{
    int iXres, iYres;
    unsigned int location;
    unsigned int RgbData = 0;
    char* cpPngDispAddr = NULL;
    
    /* ��ȡ��Ļ��Ϣ */
    GetDispResolution(&iXres,&iYres);

    /* ��ȡ�Դ��ַ */
	cpPngDispAddr = GetDispVedioMemAddr();

	location = ptRgb->xPos * 4 + ptRgb->yPos * iXres* 4;
    RgbData = *((unsigned int*)(cpPngDispAddr + location));
    
    ptRgb->R = (RgbData >> 16) & 0xFF;
    ptRgb->G = (RgbData >> 8)  & 0xFF;
    ptRgb->B = RgbData         & 0xFF;
    
    return;
}

/**************************************************************
 *  ��������: ���һ���� 
 *  ��ڲ���:
 *      PngRGBA : ǰ��ɫ��RGBA����
 *      PngBkRGB: ����ɫ��RGB����
 *  ����ֵ  : ��Ϻ��RGBֵ
***************************************************************/
static unsigned int AlphaBlend(PT_PNG_INFO PngRGBA, PT_PNG_INFO PngBkRGB, char IsDoAlphaBlend)
{
    unsigned char r = 0, g = 0, b = 0;

    if(!IsDoAlphaBlend)
    {
	    r = PngRGBA->R;
	    g = PngRGBA->G;
	    b = PngRGBA->B;
    }
    else 
    {
        r = (unsigned char)(PngRGBA->R * (PngRGBA->A / 255.0) + (PngBkRGB->R * (255 - PngRGBA->A)) / 255.0);
        g = (unsigned char)(PngRGBA->G * (PngRGBA->A / 255.0) + (PngBkRGB->G * (255 - PngRGBA->A)) / 255.0);
        b = (unsigned char)(PngRGBA->B * (PngRGBA->A / 255.0) + (PngBkRGB->B * (255 - PngRGBA->A)) / 255.0);
    }
    return ((r << 16) | (g << 8) | (b));
} 


/**************************************************************
 *  ��������: дһ�����ݵ��Դ�
 *  ��ڲ���:
 *      ptVedioMem : �Դ��ַ
 *      iXStart    : x������ʼ����
 *      iXEnd      : x�����������
 *      iY         : y��������
 *      ucpDispBuff: һ��RGBAֵ���׵�ַ
 *  ����ֵ  : ��
***************************************************************/
static void WriteOneLineToMem(char* ptVedioMem, int iXStart, int iXEnd, int iY, unsigned char* ucpDispBuff, char IsDoAlphaBlend)
{
    int iX = 0, iPoint = 0;
    unsigned int udwData = 0;
    int iXres, iYres;
    unsigned int location;
    T_PNG_INFO tPngRGBA = {0}; 
    T_PNG_INFO tPngBkRGB = {0};
    
    GetDispResolution(&iXres,&iYres);

    if(iXEnd > iXres)    return -1;
    if(iY > iYres)    return -1;
     
    for(iX = iXStart; iX < iXEnd; iX++)
    {
        /* H->L */
        /* R-G-B */        
        location = iX * 4 + iY * iXres* 4;

        if(!IsDoAlphaBlend)
        {
			/* Ԥ�˴���(ò�Ʋ���Ҫ) */
            double as = ucpDispBuff[iPoint + 3] / 255.0;
			tPngRGBA.R = (unsigned char)(ucpDispBuff[iPoint + 0] * as);
			tPngRGBA.G = (unsigned char)(ucpDispBuff[iPoint + 1] * as);
			tPngRGBA.B = (unsigned char)(ucpDispBuff[iPoint + 2] * as);
			tPngRGBA.A = ucpDispBuff[iPoint + 3];
        }
        else
        {
            /* ��ȡǰ��ɫRGBA */
	        tPngRGBA.R = ucpDispBuff[iPoint + 0];
	        tPngRGBA.G = ucpDispBuff[iPoint + 1];
	        tPngRGBA.B = ucpDispBuff[iPoint + 2];
	        tPngRGBA.A = ucpDispBuff[iPoint + 3];
        }
        
        if(0)
        {
	        DEBUG_Print("%4X",ucpDispBuff[iPoint + 0]);
	        DEBUG_Print("%4X",ucpDispBuff[iPoint + 1]);
	        DEBUG_Print("%4X",ucpDispBuff[iPoint + 2]);
	        DEBUG_Print("%4X",ucpDispBuff[iPoint + 3]);

	        if(0 == (iX % 8)) DEBUG_Print("\n");
        }
        
        /* ��ȡ����ɫRGB */
        udwData = *((unsigned int*)(ptVedioMem + location));
        tPngBkRGB.R = (udwData >> 16) & 0xFF;
	    tPngBkRGB.G = (udwData >> 8)  & 0xFF;
	    tPngBkRGB.B = udwData         & 0xFF;
        
        udwData = AlphaBlend(&tPngRGBA, &tPngBkRGB, IsDoAlphaBlend);
#if 0
        DEBUG_Print("%12x",udwData);
        if((iX % 16) == 0)
            DEBUG_Print("\n");
#endif
        *((unsigned int*)(ptVedioMem + location)) = udwData;    //rgb888_to_rgb565(udwData);

        iPoint += 4;  /* RGBA */
    }
    return 0;
}


/* Check to see if a file is a PNG file using png_sig_cmp().  png_sig_cmp()
 * returns zero if the image is a PNG and nonzero if it isn't a PNG.
 *
 * The function check_if_png() shown here, but not used, returns nonzero (true)
 * if the file can be opened and is a PNG, 0 (false) otherwise.
 *
 * If this call is successful, and you are going to keep the file open,
 * you should call png_set_sig_bytes(png_ptr, PNG_BYTES_TO_CHECK); once
 * you have created the png_ptr, so that libpng knows your application
 * has read that many bytes from the start of the file.  Make sure you
 * don't call png_set_sig_bytes() with more than 8 bytes read or give it
 * an incorrect number of bytes read, or you will either have read too
 * many bytes (your fault), or you are telling libpng to read the wrong
 * number of magic bytes (also your fault).
 *
 * Many applications already read the first 2 or 4 bytes from the start
 * of the image to determine the file type, so it would be easiest just
 * to pass the bytes to png_sig_cmp() or even skip that if you know
 * you have a PNG file, and call png_set_sig_bytes().
 */
int check_if_png(char *file_name, FILE **fp)
{
   char buf[PNG_BYTES_TO_CHECK];

   /* Open the prospective PNG file. */
   if ((*fp = fopen(file_name, "rb")) == NULL)
   {
      DEBUG_Print("open %s failed\n",file_name);
      return 0;
   }
      
   /* Read in some of the signature bytes */
   if (fread(buf, 1, PNG_BYTES_TO_CHECK, *fp) != PNG_BYTES_TO_CHECK)
   {
      DEBUG_Print("read %s failed\n",file_name);
      return 0;
   }
   
   /* Compare the first PNG_BYTES_TO_CHECK bytes of the signature.
      Return nonzero (true) if they match */

   return(!png_sig_cmp(buf, (png_size_t)0, PNG_BYTES_TO_CHECK));
}

/* Read a PNG file.  You may want to return an error code if the read
 * fails (depending upon the failure).  There are two "prototypes" given
 * here - one where we are given the filename, and we need to open the
 * file, and the other where we are given an open file (possibly with
 * some or all of the magic bytes read - see comments above).
 */
int read_png(char* filename, char IsDoAlphaBlend)  /* File is already open */
{
	FILE *fp;
	png_structp png_ptr;
	png_infop info_ptr;
	png_uint_32 width, height;
	png_uint_32 row;
	int bit_depth, color_type, interlace_type, number_passes;
	int pass,y;
	char* cpPngDispAddr = NULL;
	char* RGB_Data = NULL;
	unsigned int x = 0;
	unsigned int pos = 0;
	unsigned int i = 0;
	int iXres = 0, iYres = 0;
	T_PNG_INFO tPngInfo = {0};

   if ((fp = fopen(filename, "rb")) == NULL)
   {
      DEBUG_Print("open %s failed\n",filename);
      return 0;
   }

   /* Create and initialize the png_struct with the desired error handler
    * functions.  If you want to use the default stderr and longjump method,
    * you can supply NULL for the last three parameters.  We also supply the
    * the compiler header file version, so that we know if the application
    * was compiled with a compatible version of the library.  REQUIRED
    */
   png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING,
      NULL, NULL, NULL);

   if (png_ptr == NULL)
   {
      fclose(fp);
      return (FALSE);
   }

   /* Allocate/initialize the memory for image information.  REQUIRED. */
   info_ptr = png_create_info_struct(png_ptr);
	if (info_ptr == NULL)
	{
		fclose(fp);
		png_destroy_read_struct(&png_ptr, NULL, NULL);
		return (FALSE);
	}


    /* One of the following I/O initialization methods is REQUIRED */
    /* Set up the input control if you are using standard C streams */
    png_init_io(png_ptr, fp);

   	/* ��ȡ�Դ��ַ */
	cpPngDispAddr = GetDispVedioMemAddr();
	GetDispResolution(&iXres,&iYres);

#ifdef hilevel

   png_read_png(png_ptr, info_ptr, PNG_TRANSFORM_EXPAND, NULL);

   width = png_get_image_width( png_ptr, info_ptr );
   height = png_get_image_height( png_ptr, info_ptr );
   DEBUG_Print("width          ---- > [%4d]\n",width);
   DEBUG_Print("height         ---- > [%4d]\n",height);

   /* ����RGB�ڴ�ռ� */
	RGB_Data = (char*)malloc(width * 3);
	memset(RGB_Data, 0, width * 3);
	DEBUG_Print("1 RGB_Data -- > [0x%x]\n",RGB_Data);

	png_bytep *row_point = NULL;

   row_point = png_get_rows( png_ptr, info_ptr );
   
   /* ��ӡ����ͼƬ����Ϣ */
   for (y = 0; y < height; y++)
   {
		for(x = 0; x < width * 4; x += 4)
		//for(x = 1; x <= width * 4; x++)
		{
		    
			RGB_Data[pos++] = row_point[y][x + 0]; /* R */
			RGB_Data[pos++] = row_point[y][x + 1]; /* G */
			RGB_Data[pos++] = row_point[y][x + 2]; /* B */

			/*
			DEBUG_Print("%4x",row_point[y][x]);
			if((x % 32) == 0)
				  DEBUG_Print("\n");
		    */
		} 
/*
        DEBUG_Print("pos --- > [%d]\n",pos);
		for(i = 0; i < pos; i++)
		{
            DEBUG_Print("%4x",RGB_Data[i]);
			if(((i % 32) == 0) && (i != 0))
				  DEBUG_Print("\n");
		}
		
		DEBUG_Print("\n");
*/
        pos = 0;
        if(width > iXres)    width = iXres;
        if(height > iYres)   height = iYres;  
		WriteOneLineToMem(cpPngDispAddr, (iXres - width)/2, (iXres - width)/2 + width, (iYres - height)/2 + y, RGB_Data, IsDoAlphaBlend);
	}	
	DEBUG_Print("Disp %s over\n",filename);
	DEBUG_Print("2 RGB_Data -- > [0x%x]\n",RGB_Data);

#else
   /* OK, you're doing it the hard way, with the lower-level functions */

   /* The call to png_read_info() gives us all of the information from the
    * PNG file before the first IDAT (image data chunk).  REQUIRED
    */
   png_read_info(png_ptr, info_ptr);

   png_get_IHDR(png_ptr, info_ptr, &width, &height, &bit_depth, &color_type,
       &interlace_type, NULL, NULL);
       
   DEBUG_Print("width          ---- > [%4d]\n",width);
   DEBUG_Print("height         ---- > [%4d]\n",height);
   DEBUG_Print("bit_depth      ---- > [%4d]\n",bit_depth);
   DEBUG_Print("color_type     ---- > [%4d]\n",color_type);
   DEBUG_Print("interlace_type ---- > [%4d]\n",interlace_type);

   /* Turn on interlace handling.  REQUIRED if you are not using
    * png_read_image().  To see how to handle interlacing passes,
    * see the png_read_row() method below:
    */
   number_passes = png_set_interlace_handling(png_ptr);
   
   DEBUG_Print("number_passes  ---- > [%4d]\n",number_passes);

   /* The easiest way to read the image: */
   png_bytep row_pointers[height];

   /* Clear the pointer array */
   for (row = 0; row < height; row++)
      row_pointers[row] = NULL;

   for (row = 0; row < height; row++)
      row_pointers[row] = malloc(width * 4);  /* RGBA */
   for (row = 0; row < height; row++)
	  memset(row_pointers[row], 0, width * 4);

   /* ����RGB�ڴ�ռ� */
	RGB_Data = (char*)malloc(width * 3);
	memset(RGB_Data, 0, width * 3);
	DEBUG_Print("1 RGB_Data -- > [0x%x]\n",RGB_Data);

   /* Now it's time to read the image.  One of these methods is REQUIRED */
#ifdef entire /* Read the entire image in one go */

   png_read_image(png_ptr, row_pointers);
   
   for (y = 0; y < height; y++)
   {
		for(x = 0; x < width * 4; x += 4)
		{
			RGB_Data[pos++] = row_pointers[y][x + 0];
			RGB_Data[pos++] = row_pointers[y][x + 1];
			RGB_Data[pos++] = row_pointers[y][x + 2];
		}

		WriteOneLineToMem(cpPngDispAddr, 50, 50 + width, 50, RGB_Data, IsDoAlphaBlend);
	}

#else  /* Read the image one or more scanlines at a time */
   /* The other way to read images - deal with interlacing: */

	if(width > iXres)	  width = iXres;
	if(height > iYres)   height = iYres;
	
	for (pass = 0; pass < number_passes; pass++)
	{
		/* һ��һ�ж�ȡ����ʾ */
		for (y = 0; y < height; y++)
		{
			 png_read_rows(png_ptr, &row_pointers[y], NULL, 1);
			 WriteOneLineToMem(cpPngDispAddr, (iXres - width)/2, (iXres - width)/2 + width, (iYres - height)/2 + y, &row_pointers[y][0], IsDoAlphaBlend);
		}
	}
#endif /* Use only one of these two methods */

   /* Read rest of file, and get additional chunks in info_ptr - REQUIRED */
   png_read_end(png_ptr, info_ptr);
#endif

    /* At this point you have read the entire image */

    /* Clean up after the read, and free any memory allocated - REQUIRED */
    png_destroy_read_struct(&png_ptr, &info_ptr, NULL);

    /* ͳһ�ͷ��ڴ� */
	for (row = 0; row < height; row++)
	{
		free(row_pointers[row]);
	}
    free(RGB_Data);

    /* Close the file */
    fclose(fp);

    /* That's it */
    return (TRUE);
}



