#include "config.h"

static PT_PicOpr ptPicOprHead;

int RegisterPicOpr(PT_PicOpr ptPicOpr)
{
    PT_PicOpr ptTmp;
    /* �������Ϊ�� */
    if(!ptPicOprHead)
    {
        ptPicOprHead = ptPicOpr;
        ptPicOpr->next = NULL;
    }
    else
    {
        ptTmp = ptPicOprHead;
        while(ptTmp->next)
        {
            ptTmp = ptTmp->next;
        }
        ptTmp->next = ptPicOpr;
        ptPicOpr->next = NULL;
    }
    return 0;
}

void ShowPicList(void)
{
    PT_PicOpr ptTmp = ptPicOprHead;
    while(ptTmp)
    {
        DEBUG_Print("%s\n",ptTmp->name);
        ptTmp = ptTmp->next;
    }
}

int ShowPicture(PT_VedioMem ptVedioMem, int iX, int iY, char* cpPicName, char* cpPicFormat)
{
    PT_PicOpr ptTmp = ptPicOprHead;
    while(ptTmp)
    {
        if(strcmp(ptTmp->name,cpPicFormat) == 0)
        {
            //DEBUG_Print("found picture format %s\n",ptTmp->name);
            if(ptTmp->DispPic(ptVedioMem,iX,iY,cpPicName) == 0)
            {
                //DEBUG_Print("%s,%s\n",__FUNCTION__, ptTmp->name);
                return 0;
            }
            else
                return -1;
        }
        ptTmp = ptTmp->next;
    }
    return -1;
}



int PicInit(void)
{
    int Error;
    Error = BmpRegister();
    Error |= JpegRegister();
    return Error;
}

