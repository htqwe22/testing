#include "config.h"
#include "jpeglib.h"
#include <setjmp.h>

T_PicOpr JpegPicOpr;


static void WriteOneLineToVedioMem(PT_VedioMem ptVedioMem, int iXStart, int iXEnd, int iY, unsigned char* ucpDispBuff)
{
    int iX = 0, iPoint = iXStart * 3;
    unsigned int udwData = 0;
    unsigned int location;

    if(iXEnd > 800)    return -1;
    if(iY > 480)    return -1;
     
    for(iX = iXStart; iX < iXEnd; iX++)
    {
        udwData = (ucpDispBuff[iPoint + 0] << 16) | (ucpDispBuff[iPoint + 1] << 8) | (ucpDispBuff[iPoint + 2] << 0);
        iPoint += 3;
        location = iX * 4 + iY * ptVedioMem->iVedioWidth * 4;
        *((unsigned int*)(ptVedioMem->ucPixelDatas + location)) = udwData;    //rgb888_to_rgb565(udwData);
    }
    return 0;
}

static int JpegDispPic(PT_VedioMem ptVedioMem, int iX, int iY, char* cpPic)
{
	unsigned char *buffer;
    struct jpeg_decompress_struct cinfo;
	struct jpeg_error_mgr jerr;
	FILE * infile;

	/* 1. Allocate and initialize a JPEG decompression object. */
	cinfo.err = jpeg_std_error(&jerr);
	jpeg_create_decompress(&cinfo);

	
	/* 2. Specify the source of the compressed data (eg, a file). */
	if ((infile = fopen(cpPic, "rb")) == NULL) {
	    DEBUG_Print("can't open %s\n", cpPic);
	    return -1;
	}	
	jpeg_stdio_src(&cinfo, infile);

	/* 3. Call jpeg_read_header() to obtain image info. */
    jpeg_read_header(&cinfo, TRUE);
    DEBUG_Print("image_width: %d\n",cinfo.image_width);
    DEBUG_Print("image_height: %d\n",cinfo.image_height);
    DEBUG_Print("num_components: %d\n",cinfo.num_components);
    

    /* 4. Set parameters for decompression. */

    
    /* 5. jpeg_start_decompress(...); */
    jpeg_start_decompress(&cinfo);
    DEBUG_Print("output_width: %d\n",cinfo.output_width);
    DEBUG_Print("output_height: %d\n",cinfo.output_height);
    DEBUG_Print("output_components: %d\n",cinfo.output_components);

    /* 6. while (scan lines remain to be read) */
    buffer = (unsigned char*)malloc(cinfo.output_width * cinfo.output_components);
    while(cinfo.output_scanline < cinfo.output_height)
    {
        (void) jpeg_read_scanlines(&cinfo, &buffer, 1);
        WriteOneLineToVedioMem(ptVedioMem, iX, cinfo.output_width, cinfo.output_scanline + iY, buffer);
    }

	free(buffer);

	/* 7. jpeg_finish_decompress(...); */
	jpeg_finish_decompress(&cinfo);

	/* 8. Release the JPEG decompression object. */
	jpeg_destroy_decompress(&cinfo);
	

    return 0;
}


T_PicOpr JpegPicOpr = {
    .name = "jpeg",
    .DispPic = JpegDispPic,
};

int JpegRegister(void)
{
    return (RegisterPicOpr(&JpegPicOpr));
}


