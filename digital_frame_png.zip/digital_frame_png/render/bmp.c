#include "config.h"


T_PicOpr BmpPicOpr;

static void DrawPointToVedioMem(PT_VedioMem ptVedioMem, int iX, int iY, unsigned int udwColor)
{
    unsigned int location = iX * 4 + iY * ptVedioMem->iVedioWidth * 4;
    *((unsigned int*)(ptVedioMem->ucPixelDatas + location)) = udwColor;     //rgb888_to_rgb565(udwColor);
}

static int BmpDispPic(PT_VedioMem ptVedioMem, int iX, int iY, char* cpPic)
{
    int iFd;
	T_BMPINFO tBmpInfo;
	struct stat tBmpStat;
	char *cpBmpMem;
	int iTempX,iTempY,iLoop = 0;
	char* cpPoint;
	char* cpDest;
	unsigned int udwRgbData = 0;
	char* cpAddr;
	int iAilgnWidth;
	
	memset(&tBmpInfo,0,sizeof(T_BMPINFO));
	iFd = open(cpPic,O_RDONLY);
	if(iFd < 0)
	{
		DEBUG_Print("Error: can't open file: %s\n",cpPic);
		return -1;
	}
	/* ����ͷ�ļ� */
	if(read(iFd,&tBmpInfo,sizeof(T_BMPINFO)) < 0)
	{
		DEBUG_Print("Error: read bmp head\n");
		return -1;
	}
	/* ӳ��BMPͼƬ���ڴ� */
	fstat(iFd, &tBmpStat);
	cpBmpMem = (char *)mmap(NULL,tBmpStat.st_size,PROT_READ,MAP_SHARED,iFd,0);
    if(cpBmpMem  == (void*)-1)
    {
        DEBUG_Print("Error can't map the bmp_mem to memory.\n");
        return -1;
    }
	//DEBUG_Print("udwOffset: %d\n",tBmpInfo.udwOffset);
	//DEBUG_Print("udStructSize: %d\n",tBmpInfo.udStructSize);
	//DEBUG_Print("udwFileWidth: %d\n",tBmpInfo.udwFileWidth);
	//DEBUG_Print("udwFileHeight: %d\n",tBmpInfo.udwFileHeight);
	//DEBUG_Print("udBitCount: %d\n",tBmpInfo.udBitCount);
	//DEBUG_Print("ptVedioMem->width: %d\n",ptVedioMem->iVedioWidth);

    iAilgnWidth = (((tBmpInfo.udwFileWidth * tBmpInfo.udBitCount / 8) + 3) & ~0x3) / (tBmpInfo.udBitCount / 8);
    //DEBUG_Print("iAilgnWidth: %d\n",iAilgnWidth);

    cpPoint = cpBmpMem + tBmpInfo.udwOffset;
    //cpPoint = cpPoint + (iAilgnWidth - 1) * iAilgnWidth;
    cpDest = ptVedioMem->ucPixelDatas;
    
    for(iTempY = 0; iTempY < tBmpInfo.udwFileHeight; iTempY++)
	{

		/* ��ȡͼƬ���� */
		for(iTempX = 0; iTempX < iAilgnWidth; iTempX++)
		{
		    /* R G B */
			udwRgbData = ((cpPoint[iLoop + 2] & 0xFF) << 16) | ((cpPoint[iLoop + 1] & 0xFF) << 8) | ((cpPoint[iLoop + 0] & 0xFF));       
			DrawPointToVedioMem(ptVedioMem,iX + iTempX,tBmpInfo.udwFileHeight - iTempY -1 + iY ,udwRgbData);
			iLoop += 3;
		}
	}
	munmap(cpBmpMem, tBmpStat.st_size);
	close(cpPic);
    return 0;
}


T_PicOpr BmpPicOpr = {
    .name = "bmp",
    .DispPic = BmpDispPic,
};

int BmpRegister(void)
{
    return (RegisterPicOpr(&BmpPicOpr));
}
