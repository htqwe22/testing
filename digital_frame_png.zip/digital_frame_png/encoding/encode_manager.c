#include "encode_manager.h"
#include "font_manager.h"
#include <config.h>

static PT_EncodeOpr ptAsciiOprHead = NULL;
static PT_EncodeOpr ptDefalutEncode = NULL;

int RegisterEncodeOpr(PT_EncodeOpr ptAsciiOpr)
{
    PT_EncodeOpr ptTmp;
    /* �������Ϊ�� */
    if(!ptAsciiOprHead)
    {
        ptAsciiOprHead = ptAsciiOpr;
        ptAsciiOpr->next = NULL;
    }
    else
    {
        ptTmp = ptAsciiOprHead;
        while(ptTmp->next)
        {
            ptTmp = ptTmp->next;
        }
        ptTmp->next = ptAsciiOpr;
        ptAsciiOpr->next = NULL;
    }
    return 0;
}

int AddFontToEncodeList(PT_EncodeOpr ptEncodeOpr, PT_FontOpr ptFontOpr)
{
    PT_FontOpr ptFontTemp;
    PT_FontOpr ptTmp;  /* ͷ�ڵ� */
    if(ptFontOpr == (PT_FontOpr)-1)
    {
        DEBUG_Print("can't get Font\n");
        return -1;
    }
    DEBUG_Print("get Font success %s\n",ptFontOpr->name);

    ptFontTemp = (PT_FontOpr)malloc(sizeof(T_FontOpr));
    if(!ptFontTemp)
    {
        DEBUG_Print("%s %s %d\n", __FILE__, __FUNCTION__, __LINE__);
        return -1;
    }
    
    if(memcpy(ptFontTemp,ptFontOpr,sizeof(T_FontOpr)) < 0)
    {
        DEBUG_Print("memcpy\n");
        return -1;
    }
    
    if(!ptEncodeOpr->ptFontListHead)
    {
        DEBUG_Print("%s %s %d\n", __FILE__, __FUNCTION__, __LINE__);
        ptEncodeOpr->ptFontListHead = ptFontTemp;
        ptFontTemp->next = NULL;
    }
    else
    {
        ptTmp = ptEncodeOpr->ptFontListHead;
        while(ptTmp->next)
        {
            ptTmp = ptTmp->next;
        }
        ptTmp->next= ptFontTemp;
        ptFontTemp->next = NULL;
    }
    return 0;
}

PT_EncodeOpr SelectEncode(char* pucFileHead)
{
    PT_EncodeOpr ptTmp = ptAsciiOprHead;
    while(ptTmp)
    {
        DEBUG_Print("encode file name %s\n",ptTmp->name);
        if(ptTmp->IsSupport(pucFileHead))
        {
            DEBUG_Print("found support encode %s\n",ptTmp->name);
            return ptTmp;
        }
        ptTmp = ptTmp->next;
    }
    return ((PT_EncodeOpr)-1);
}

/* Ĭ�Ͻ��������õ��������ʼ��*/
static int DefaultEncodeFontInit(PT_EncodeOpr ptEncode)
{
    PT_FontOpr ptTmp = NULL;
    
    /* ��ʼ�������ļ�*/
    ptTmp = ptEncode->ptFontListHead;
    while(ptTmp)
    {
        if(strcmp(ptTmp->name,"ascii") == 0)
            ptTmp->FontInit(NULL);
        else if(strcmp(ptTmp->name,"gbk") == 0)
            ptTmp->FontInit(HZK_FILE);

        ptTmp = ptTmp->next;
    }
    return 0;
}

PT_EncodeOpr DefaultEncodeInit(void)
{
    PT_EncodeOpr ptTmp = ptAsciiOprHead;
    while(ptTmp)
    {
        if(strcmp(ptTmp->name, DEFAULT_ENCODE) == 0)
        {
            ptDefalutEncode = ptTmp;
            DefaultEncodeFontInit(ptDefalutEncode);
            DEBUG_Print("encode format is %s\n",ptDefalutEncode->name);
            return ptDefalutEncode;
        }
        ptTmp = ptTmp->next;
    }
    return (PT_EncodeOpr)-1;
}

PT_EncodeOpr GetDefaultEncode(void)
{
    return ptDefalutEncode;
}



int EncodeInit(void)
{
    return(AsciiEncodeRegister());
}
