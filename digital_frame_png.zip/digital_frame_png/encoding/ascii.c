#include "encode_manager.h"
#include "config.h"

static int IsAsciiSupport(char* pucFileHead);
static int AsciiGetEncodeFromBuf(char* pucFileStart, char* pucEndOfTheFile, char* pucCodeBuff);


static T_EncodeOpr T_AsciiOpr = {
    .name = "ascii",
    .IsSupport = IsAsciiSupport,
    .GetEncodeFromBuf = AsciiGetEncodeFromBuf,
};


static int IsAsciiSupport(char* pucFileHead)
{
    char unicode[3] = {0xFF,0xFE,0};
    char utf8[4] = {0xEF,0xBB,0xBF,0};
    //DEBUG_Print("%s %s %d %s\n", __FILE__, __FUNCTION__, __LINE__,pucFileHead);
    if(strncmp(unicode,pucFileHead,2) == 0)
    {
        DEBUG_Print("is unicode encode\n");
        return 0;
    }
    else if(strncmp(utf8,pucFileHead,3) == 0)
    {
        DEBUG_Print("is utf8 encode\n");
        return 0;
    }
    DEBUG_Print("is ascii encode\n");
    return 1;
}

static int AsciiGetEncodeFromBuf(char* pucFileStart, char* pucEndOfTheFile, char* pucCodeBuff)
{
    unsigned char ucLow = *pucFileStart;
    if((pucFileStart <= pucEndOfTheFile) && (ucLow < 0x80))
    {
        *pucCodeBuff = ucLow;
        return 1;
    }
    else if(((pucFileStart + 1) <= pucEndOfTheFile) && (ucLow > 0x80))
    {
        *pucCodeBuff = ucLow;
        *(pucCodeBuff + 1) = *(pucFileStart + 1);
        return 2;
    }
    else 
        return 0;
}

int AsciiEncodeRegister(void)
{
    T_AsciiOpr.ptFontListHead = NULL;
    AddFontToEncodeList(&T_AsciiOpr, GetFontFile("ascii"));
    AddFontToEncodeList(&T_AsciiOpr, GetFontFile("gbk"));
    return RegisterEncodeOpr(&T_AsciiOpr);
}

