#include "font_manager.h"
#include "config.h"

static PT_FontOpr ptFontOprHead = NULL;

int RegisterFontOpr(PT_FontOpr ptFontOpr)
{
    PT_FontOpr ptTmp;
    /* �������Ϊ�� */
    if(!ptFontOprHead)
    {
        ptFontOprHead = ptFontOpr;
        ptFontOpr->next = NULL;
    }
    else
    {
        ptTmp = ptFontOprHead;
        while(ptTmp->next)
        {
            ptTmp = ptTmp->next;
        }
        ptTmp->next = ptFontOpr;
        ptFontOpr->next = NULL;
    }
    return 0;
}

PT_FontOpr GetFontFile(char* cName)
{  
    PT_FontOpr ptTmp = ptFontOprHead;
    while(ptTmp)
    {
        if(strcmp(cName,ptTmp->name) == 0)
        {
            DEBUG_Print("%s %s %d %s\n", __FILE__, __FUNCTION__, __LINE__, ptTmp->name);
            return ptTmp;
        }
        ptTmp = ptTmp->next;
    }
    return ((PT_FontOpr)-1);
}

void ShowOneWord(char* cDispMem, PT_FontBitMap ptFontWordMap, char* cWord, int uwPenX, int uwPenY, int color)
{
    int iResX,iResY;
    int dwHeight,dwWidth;
    unsigned int iData;
    int dwTemp = 0;
    char cCodebuff[6] = {0};
    unsigned int location;
    
	PT_FontOpr ptTmp = GetDefaultEncode()->ptFontListHead;
	
	GetDispResolution(&iResX,&iResY);
	 
	 /* ����һ���� */
	 GetDefaultEncode()->GetEncodeFromBuf(cWord,cWord + strlen(cWord),cCodebuff);
	 //DEBUG_Print("code is %X %X",cCodebuff[0],cCodebuff[1]);	  
     
	
	 /* �ҳ���ǰ�ֵ�����*/
	 while(ptTmp)
	 {
		 if((ptTmp->GetFontData(cCodebuff,ptFontWordMap)) == 0)
		 {
			 //DEBUG_Print("found Font bit map \n");
			 break;
		 }
		 else
		 {
			 ptTmp = ptTmp->next;
		 }
	 }

    
    /* ���һ����*/
    for(dwHeight = 0;dwHeight < ptFontWordMap->iHeight; dwHeight++)
    {
        for(dwWidth = 0; dwWidth < ptFontWordMap->iWidth; dwWidth++)
        {
            if(!(dwWidth % 8))
                iData = (unsigned int)ptFontWordMap->pucBitMap[dwTemp++];
            if(iData & 0x80)
            {
                location = (uwPenX + dwWidth) * 4 + (uwPenY + dwHeight) * iResX * 4;
                *((unsigned int*)(cDispMem + location)) = color;    //rgb888_to_rgb565(color);
            }
            iData <<= 1;
        }
    }
    
}


void ShowString(char* cDispMem, char* string, int iX, int iY,unsigned int iColor)
{
    PT_FontBitMap ptFontWordMap;
    ptFontWordMap = (PT_FontBitMap)malloc(sizeof(T_FontBitMap));
	if(ptFontWordMap < 0)
	{
        DEBUG_Print("Error malloc ptFontWordMap\n");
        return;
	}
    while(*string != '\0')
    {
        ShowOneWord(cDispMem, ptFontWordMap, string, iX, iY, iColor);
        cDispMem += 4;       /* һ�������ĸ��ֽڱ�ʾ */
        iX += ptFontWordMap->iWidth;
        string += ptFontWordMap->iPitch;
    }
    free(ptFontWordMap);
}
    


int FontInit(void)
{
    AsciiFontRegister();
    GBKFontRegister();
    return 0;
}

