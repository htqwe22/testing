#include "font_manager.h"
#include "config.h"

static int GBKGetFontData(char* pucCode, PT_FontBitMap ptBitMap);
static int GBKFontInit(char* pcFile);

static T_FontOpr GBKFontOpr = 
{
    .name = "gbk",
    .FontInit = GBKFontInit,
    .GetFontData = GBKGetFontData,
};

static int g_GBKFb;
static char* pcGBKMem;
static int g_FontSize;

static int GBKFontInit(char* pcFile)
{
    struct stat stat_buf;
    g_GBKFb = open(pcFile,O_RDWR);
    if(g_GBKFb == -1)
    {
        DEBUG_Print("Error can't open %s.\n",pcFile);
        return -1;
    }
    if(fstat(g_GBKFb,&stat_buf) == -1)
    {
        DEBUG_Print("get file information failed\n");
        return -1;
    }
    g_FontSize = (int)stat_buf.st_size;
	/* map the HZK.bin to memory */
	pcGBKMem = (char *)mmap(NULL,g_FontSize,PROT_READ,MAP_SHARED,g_GBKFb,0);
	if(!pcGBKMem)
	{
		DEBUG_Print("Error can't map the HZK to memory.\n");
		return -1;
	}
	DEBUG_Print("GBKFontInit success.\n");
	return 0;
}


static int GBKGetFontData(char* pucCode, PT_FontBitMap ptBitMap)
{
    unsigned int pos = 0;
    unsigned char ucHigh = *pucCode;
    unsigned char ucLow = *(pucCode + 1);
    if((ucHigh < 0x80) || (((ucHigh << 8) | ucLow) & 0xffff0000))
    {
        DEBUG_Print("don't support GBK encodeing.\n");
        return -1;
    }
    pos = ((ucHigh- 0xA1) * 94 + (ucLow - 0xA1)) * 2 * 16;
    if(pos > g_FontSize)
    {
        ptBitMap->pucBitMap = (unsigned char*)(pcGBKMem + 0);
		ptBitMap->iWidth = 16;
		ptBitMap->iHeight = 16;
		ptBitMap->iPitch = 2;
		DEBUG_Print("can't display this word @_@\n");
        return -1;
    }
    ptBitMap->pucBitMap = (unsigned char*)(pcGBKMem + pos);
    ptBitMap->iWidth = 16;
    ptBitMap->iHeight = 16;
    ptBitMap->iPitch = 2;
    return 0;
}

int GBKFontRegister(void)
{
    return (RegisterFontOpr(&GBKFontOpr));
}


